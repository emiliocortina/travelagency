package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.BoxLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import logic.Accommodation;
import logic.ProductType;

import java.awt.Cursor;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AccommodationsScreen extends JPanel {

	private MainWindow contenedor;
	private JPanel rightButtons;
	private JLabel lblCart;
	private JPanel navBar;
	private JPanel leftButtons;
	private JLabel lblTitle;
	private JLabel leftArrow;
	private JLabel lblHome;
	private JScrollPane scrollPane;
	private JPanel panel;
	private JPanel panel_1;
	private CardListener cardListener = new CardListener();
	private JButton btnBack;
	private JButton btnCart;
	private JButton btnHome;
	
	
	/**
	 * Create the panel.
	 */
	public AccommodationsScreen(MainWindow container) {
		setBackground(Color.decode("#FFF9ED"));
		setLayout(new BorderLayout(0, 0));
		this.contenedor = container;
		add(getNavBar(), BorderLayout.NORTH);
		add(getScrollPane_1(), BorderLayout.CENTER);
	}

	private JPanel getRightButtons() {
		if (rightButtons == null) {
			rightButtons = new JPanel();
			FlowLayout fl_rightButtons = (FlowLayout) rightButtons.getLayout();
			fl_rightButtons.setHgap(25);
			fl_rightButtons.setAlignment(FlowLayout.RIGHT);
			// panel.setBackground(Color.decode("#007396"));
			rightButtons.setOpaque(false);
			rightButtons.add(getBtnCart());
			rightButtons.add(getBtnHome());
			//rightButtons.add(getLblCart());
			//rightButtons.add(getLblHome());
		}
		return rightButtons;
	}

//	private JLabel getLblCart() {
//		if (lblCart == null) {
//			lblCart = new JLabel("");
//			lblCart.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					contenedor.showPanel("cart");
//				}
//			});
//			lblCart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			lblCart.setHorizontalTextPosition(SwingConstants.RIGHT);
//			lblCart.setHorizontalAlignment(SwingConstants.RIGHT);
//			lblCart.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/cart.png")));
//		}
//		return lblCart;
//	}

	private JPanel getNavBar() {
		if (navBar == null) {
			navBar = new JPanel();
			navBar.setLayout(new BorderLayout(0, 0));
			navBar.add(getLeftButtons(), BorderLayout.WEST);
			navBar.add(getLblTitle(), BorderLayout.CENTER);
			navBar.add(getRightButtons(), BorderLayout.EAST);
			navBar.setBackground(Color.decode("#007396"));
		}
		return navBar;
	}

	private JPanel getLeftButtons() {
		if (leftButtons == null) {
			leftButtons = new JPanel();
			leftButtons.setOpaque(false);
			leftButtons.add(getBtnBack());
			//leftButtons.add(getLeftArrow());
		}
		return leftButtons;
	}

	private JLabel getLblTitle() {
		if (lblTitle == null) {
			lblTitle = new JLabel("");
			lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
			lblTitle.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/accTitle.png")));
		}
		return lblTitle;
	}

//	private JLabel getLeftArrow() {
//		if (leftArrow == null) {
//			leftArrow = new JLabel("");
//			leftArrow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			leftArrow.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					contenedor.showPanel("welcome");
//				}
//			});
//			leftArrow.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/backArrow.png")));
//		}
//		return leftArrow;
//	}

//	private JLabel getLblHome() {
//		if (lblHome == null) {
//			lblHome = new JLabel("");
//			lblHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			lblHome.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					contenedor.showPanel("welcome");
//				}
//			});
//			lblHome.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/home.png")));
//		}
//		return lblHome;
//	}

	private JScrollPane getScrollPane_1() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.getViewport().setOpaque(false);
			scrollPane.setOpaque(false);
			scrollPane.setViewportView(getPanel_1_1());
			scrollPane.getVerticalScrollBar().setUnitIncrement(16);
			// scrollPane.setViewportView(getPanel_1());

		}
		return scrollPane;
	}

	private JPanel getPanel_1() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(new GridLayout());
			panel.setOpaque(false);
		}
		return panel;
	}

	private JPanel getPanel_1_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBorder(new MatteBorder(1, 50, 1, 50, Color.decode("#FFF9ED")));
			panel_1.setOpaque(false);
			panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.Y_AXIS));
			
			for(Accommodation acc : contenedor.getAgency().getAccommodations()) {
				CardPanel cardPanel = new CardPanel(acc, ProductType.ACC);
				cardPanel.addListenerToCard(cardListener);
				panel_1.add(cardPanel, acc.getCode());
			}

		}
		return panel_1;
	}
	
	private class CardListener extends MouseAdapter{
		@Override
		public void mouseClicked(MouseEvent e) {
			contenedor.bookingScreen.showProduct((((CardPanel) ((JPanel)e.getComponent()).getParent()).getProduct()) , (((CardPanel) ((JPanel)e.getComponent()).getParent()).getProductType()));
			contenedor.showPanel("booking");
			//contenedor.getContentPane().add(comp, constraints);
			//contenedor.showPanel((((CardPanel) ((JPanel)e.getComponent()).getParent()).getCode())) ;
		}
	}
	private JButton getBtnBack() {
		if (btnBack == null) {
			btnBack = new JButton("");
			btnBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnBack.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("welcome");
				}
			});
			btnBack.setVerticalAlignment(SwingConstants.TOP);
			btnBack.setFont(new Font("Lucida Grande", Font.PLAIN, 5));
			btnBack.setOpaque(false);
			btnBack.setContentAreaFilled(false);
			btnBack.setBorderPainted(false);
			btnBack.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/backArrow.png")));
		}
		return btnBack;
	}
	private JButton getBtnCart() {
		if (btnCart == null) {
			btnCart = new JButton("");
			btnCart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnCart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("cart");
				}
			});
			btnCart.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/cart.png")));
			btnCart.setOpaque(false);
			btnCart.setContentAreaFilled(false);
			btnCart.setBorderPainted(false);
		}
		return btnCart;
	}
	private JButton getBtnHome() {
		if (btnHome == null) {
			btnHome = new JButton("");
			btnHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnHome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("welcome");
				}
			});
			btnHome.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/home.png")));
			btnHome.setOpaque(false);
			btnHome.setContentAreaFilled(false);
			btnHome.setBorderPainted(false);
		}
		return btnHome;
	}
}
