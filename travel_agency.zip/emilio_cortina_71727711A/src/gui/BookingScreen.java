package gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import logic.*;
import logic.Package;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.border.LineBorder;
import javax.swing.border.BevelBorder;
import com.toedter.calendar.JDateChooser;
import javax.swing.BoxLayout;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;

import java.awt.event.ActionListener;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.GridLayout;
import javax.swing.JTextArea;

public class BookingScreen extends JPanel {

	private ProductType productType;
	private Product product;
	private JPanel panel;
	private JPanel navBar;
	private JPanel pnLeft;
	private JPanel pnRight;
	private JLabel lblHeader;

	private final static String ACC_COLOR = "#007396";
	private final static String PACK_COLOR = "#860039";
	private final static String TICKET_COLOR = "#0F4D46";

	private String mainColor;
	private String secondaryColor;
	private JLabel backArrow;
	private JLabel lblHome;
	private JLabel lblCart;
	private JPanel pnDescription;
	private JPanel pnBook;
	private JLabel lblTitle;
	private JPanel pnBookHeader;
	private JLabel lblBookHeader;
	private JPanel pnBookLeft;
	private JPanel pnBookRight;
	private JPanel pnBookCenter;
	private JLabel lblStartDate;
	private JLabel lblEndDate;
	private JPanel pnBR1;
	private JDateChooser dateChooser;
	private JDateChooser dateChooser2;
	private MainWindow contenedor;
	private JPanel pnBookLeft1;
	private JPanel pnBookLeft2;
	private JPanel pnBookLeft3;

	private JSpinner spinner1;
	private JSpinner spinner2;
	private JTextField textField1;
	private JPanel pnAddToCart;
	private JLabel lblAddToCart;
	private JPanel pnDescriptionTop;
	private JPanel pnRating;
	private JPanel pnDescriptionCenter;
	private JLabel lblProductType;
	private JTextArea taDescription;
	private JLabel lblSeparator;
	private long nights;
	private JLabel lblPrice;
	private JLabel lblProductImg;
	private JPanel pnProductImg;
	private JButton btnBack;
	private JButton btnHome;
	private JButton btnCart;
	private JButton btnAddToCart;
	private JCheckBox chckbxBreakfast;

	public BookingScreen(MainWindow contenedor) {
		this.contenedor = contenedor;
		mainColor = TICKET_COLOR;
		secondaryColor = PACK_COLOR;
		setBackground(Color.decode("#FFF9ED"));
		setLayout(new BorderLayout(0, 0));
		add(getNavBar(), BorderLayout.NORTH);
		add(getPnDescription(), BorderLayout.WEST);
		add(getPnBook(), BorderLayout.EAST);
	}

	public void showProduct(Product product, ProductType productType) {
		//this.product = product;
		switch(productType) {
		case ACC:
			this.product= new Accommodation((Accommodation)product);
			break;
		case TICKET:
			this.product= new Ticket((Ticket)product);
			break;
		case PACK:
			this.product= new Package((Package)product);
			break;
		}
		
		this.productType = productType;

		setColors();
		navBar.setBackground(Color.decode(mainColor));

		paintBookPanel();
		paintDescriptionPanel();
	}

	private void setColors() {
		switch (productType) {
		case ACC:
			mainColor = ACC_COLOR;
			secondaryColor = "#BA004F";
			break;
		case PACK:
			mainColor = PACK_COLOR;
			secondaryColor = ACC_COLOR;
			break;
		case TICKET:
			mainColor = TICKET_COLOR;
			secondaryColor = PACK_COLOR;
			break;
		default:
			mainColor = TICKET_COLOR;
			secondaryColor = PACK_COLOR;
			break;
		}
	}

	private void paintBookPanel() {
		// Clear all dynamic elements.
		getSpinner1().setValue(0);
		getSpinner2().setValue(0);
		getTF1().setText(null);
		getDateChooser().setDate(null);
		getDateChooser2().setDate(null);

		pnBookLeft1.removeAll();
		pnBookLeft2.removeAll();
		pnBookLeft3.removeAll();

		switch (productType) {
		case ACC:
			dateChooser2.setEnabled(true);

			pnBookLeft1.add(getIconLabel("nights.png"));
			pnBookLeft1.add(new JLabel("Nights: "));
			pnBookLeft1.add(getTF1());

			pnBookLeft2.add(getIconLabel("people.png"));
			pnBookLeft2.add(new JLabel("People: "));
			pnBookLeft2.add(getSpinner1());

			//lblAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingBlueButton.png")));
			btnAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingBlueButton.png")));
			if(((Accommodation)product).isHotel()){
				pnBookLeft3.add(getIconLabel("breakfast.png"));
				
				pnBookLeft3.add(getChckbxBreakfast());
			}
			break;

		case TICKET:
			dateChooser2.setEnabled(true);

			pnBookLeft1.add(getIconLabel("people.png"));
			pnBookLeft1.add(new JLabel("Adults:   "));
			pnBookLeft1.add(getSpinner1());

			pnBookLeft2.add(getIconLabel("children.png"));
			pnBookLeft2.add(new JLabel("Children: "));
			pnBookLeft2.add(getSpinner2());

			
			//lblAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
			btnAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
			
			break;
		case PACK:
			dateChooser2.setEnabled(false);

			pnBookLeft1.add(getIconLabel("people.png"));
			pnBookLeft1.add(new JLabel("Adults:   "));
			pnBookLeft1.add(getSpinner1());

			pnBookLeft2.add(getIconLabel("children.png"));
			pnBookLeft2.add(new JLabel("Children: "));
			pnBookLeft2.add(getSpinner2());

			//lblAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
			btnAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
			
			break;
		}

	}

	private void paintDescriptionPanel() {
		pnRating.removeAll();

		lblTitle.setForeground(Color.BLACK);
		lblTitle.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		lblTitle.setText(product.getName());
		lblProductType.setText(product.getClassification());

		if (productType.equals(ProductType.ACC)) {
			for (int i = 0; i < 5; i++) {
				if (i < ((Accommodation) product).getCategory()) {
					pnRating.add(getIconLabel("filledStar.png"));
				} else {
					pnRating.add(getIconLabel("emptyStar.png"));
				}
			}
		}
		try {
			if (!productType.equals(ProductType.PACK)) {
				lblProductImg.setIcon(MainWindow.resizeImageIcon("/img/products/" + product.getJpg(), 120, 120));
			}else {
				lblProductImg.setIcon(MainWindow.resizeImageIcon("/img/products/" + ((Package)product).getAccommodation().getJpg(), 120, 120));
			}
			lblProductImg.setVerticalAlignment(SwingConstants.TOP);
			lblProductImg.setBorder(new LineBorder(Color.decode(mainColor), 3, true));

		} catch (Exception e) {
			lblProductImg.setIcon(null);
			lblProductImg.setBorder(null);
		}
		taDescription.setText(product.getDescription());
	}

	private JTextField getTF1() {
		if (textField1 == null) {
			textField1 = new JTextField();
			textField1.setColumns(2);
			textField1.setEditable(false);
		}
		return textField1;
	}

	private JLabel getIconLabel(String name) {
		JLabel imgLabel = new JLabel("");
		imgLabel.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/" + name)));
		return imgLabel;
	}

	private JLabel getProductIconLabel(String name) {
		JLabel imgLabel = new JLabel("");
		imgLabel.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/products/" + name)));
		return imgLabel;
	}

	private JSpinner getSpinner1() {
		if (spinner1 == null) {
			spinner1 = new JSpinner(new SpinnerNumberModel(0, 0, 9, 1));
			spinner1.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					try {
						setPeople();
						displayPrice();
					} catch (Exception ex) {
						System.out.println("Ni idea");
					}
				}
			});
		}
		return spinner1;
	}

	private JSpinner getSpinner2() {
		if (spinner2 == null) {
			spinner2 = new JSpinner(new SpinnerNumberModel(0, 0, 9, 1));
			spinner2.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					try {
						setPeople();
						displayPrice();
					} catch (Exception ex) {
					}
				}
			});
		}
		return spinner2;
	}

	private JPanel getNavBar() {
		if (navBar == null) {
			navBar = new JPanel();
			navBar.setLayout(new BorderLayout(0, 0));
			navBar.setBackground(Color.decode(mainColor));
			navBar.add(getPnLeft(), BorderLayout.WEST);
			navBar.add(getLblHeader(), BorderLayout.CENTER);
			navBar.add(getPnRight(), BorderLayout.EAST);
		}
		return navBar;
	}

	private JPanel getPnLeft() {
		if (pnLeft == null) {
			pnLeft = new JPanel();
			pnLeft.setOpaque(false);
			pnLeft.add(getBtnBack());
		}
		return pnLeft;
	}

	private JPanel getPnRight() {
		if (pnRight == null) {
			pnRight = new JPanel();
			FlowLayout flowLayout = (FlowLayout) pnRight.getLayout();
			flowLayout.setHgap(25);
			pnRight.setOpaque(false);
			pnRight.add(getBtnCart());
			pnRight.add(getBtnHome());
		}
		return pnRight;
	}

	private JLabel getLblHeader() {
		if (lblHeader == null) {
			lblHeader = new JLabel("");
			lblHeader.setHorizontalAlignment(SwingConstants.CENTER);
			lblHeader.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/bookingTitle.png")));

		}
		return lblHeader;
	}

	private JLabel getBackArrow() {
		if (backArrow == null) {
			backArrow = new JLabel("");
			backArrow.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			backArrow.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					switch (productType) {
					case ACC:
						contenedor.showPanel("accommodation");
						break;
					case PACK:
						contenedor.showPanel("package");
						break;
					case TICKET:
						contenedor.showPanel("ticket");
						break;
					}
				}
			});
			backArrow.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/backArrow.png")));
		}
		return backArrow;
	}
	
	private JButton getBtnBack() {
		if (btnBack == null) {
			btnBack = new JButton("");
			btnBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnBack.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					switch (productType) {
					case ACC:
						contenedor.showPanel("accommodation");
						break;
					case PACK:
						contenedor.showPanel("package");
						break;
					case TICKET:
						contenedor.showPanel("ticket");
						break;
					}
				}
			});
			btnBack.setVerticalAlignment(SwingConstants.TOP);
			btnBack.setFont(new Font("Lucida Grande", Font.PLAIN, 5));
			btnBack.setOpaque(false);
			btnBack.setContentAreaFilled(false);
			btnBack.setBorderPainted(false);
			btnBack.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/backArrow.png")));
		}
		return btnBack;
	}

//	private JLabel getLblHome() {
//		if (lblHome == null) {
//			lblHome = new JLabel("");
//			lblHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			lblHome.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					contenedor.showPanel("welcome");
//				}
//			});
//			lblHome.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/home.png")));
//		}
//		return lblHome;
//	}

//	private JLabel getLblCart() {
//		if (lblCart == null) {
//			lblCart = new JLabel("");
//			lblCart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			lblCart.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					contenedor.showPanel("cart");
//				}
//			});
//			lblCart.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/cart.png")));
//		}
//		return lblCart;
//	}

	private JPanel getPnDescription() {
		if (pnDescription == null) {
			pnDescription = new JPanel();
			pnDescription.setBorder(new LineBorder(Color.decode("#FFF9ED"), 50));
			pnDescription.setBackground(Color.decode("#FFF9ED"));
			pnDescription.setLayout(new BorderLayout(0, 0));
			pnDescription.add(getPnDescriptionTop(), BorderLayout.NORTH);
			pnDescription.add(getPnDescriptionCenter(), BorderLayout.CENTER);
		}
		return pnDescription;
	}

	private JPanel getPnBook() {
		if (pnBook == null) {
			pnBook = new JPanel();
			pnBook.setBorder(new LineBorder(new Color(255, 249, 237), 50));
			pnBook.setBackground(Color.WHITE);
			pnBook.setOpaque(false);
			pnBook.setLayout(new BorderLayout(0, 0));
			pnBook.add(getPnBookHeader(), BorderLayout.NORTH);
			pnBook.add(getPnBookCenter(), BorderLayout.CENTER);
		}
		return pnBook;
	}

	private JLabel getLblTitle() {
		if (lblTitle == null) {
			lblTitle = new JLabel("");
			lblTitle.setBorder(new MatteBorder(1, 1, 20, 1, Color.decode("#FFF9ED")));
		}
		return lblTitle;
	}

	private JPanel getPnBookHeader() {
		if (pnBookHeader == null) {
			pnBookHeader = new JPanel();
			pnBookHeader.setBorder(null);
			pnBookHeader.setBackground(Color.decode(secondaryColor));
			pnBookHeader.add(getLblBookHeader());
		}
		return pnBookHeader;
	}

	private JLabel getLblBookHeader() {
		if (lblBookHeader == null) {
			lblBookHeader = new JLabel("");
			lblBookHeader.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/bookNow.png")));
		}
		return lblBookHeader;
	}

	private JPanel getPnBookLeft() {
		if (pnBookLeft == null) {
			pnBookLeft = new JPanel();
			pnBookLeft.setBorder(new MatteBorder(24, 24, 24, 24, (Color) Color.WHITE));
			pnBookLeft.setOpaque(false);
			pnBookLeft.setLayout(new BoxLayout(pnBookLeft, BoxLayout.Y_AXIS));
			pnBookLeft.add(getPnBookLeft1());
			pnBookLeft.add(getPnBookLeft2());
			pnBookLeft.add(getPnBookLeft3());
		}
		return pnBookLeft;
	}

	private JPanel getPnBookRight() {
		if (pnBookRight == null) {
			pnBookRight = new JPanel();
			pnBookRight.setBackground(Color.WHITE);
			pnBookRight.setLayout(new BorderLayout(0, 0));
			pnBookRight.add(getPnBR1(), BorderLayout.NORTH);
		}
		return pnBookRight;
	}

	private JPanel getPnBookCenter() {
		if (pnBookCenter == null) {
			pnBookCenter = new JPanel();
			pnBookCenter.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
			pnBookCenter.setBackground(Color.WHITE);
			pnBookCenter.setLayout(new BorderLayout(0, 0));
			pnBookCenter.add(getPnBookRight(), BorderLayout.EAST);
			pnBookCenter.add(getPnBookLeft(), BorderLayout.WEST);
			pnBookCenter.add(getPnAddToCart(), BorderLayout.SOUTH);
		}
		return pnBookCenter;
	}

	private JLabel getLblStartDate() {
		if (lblStartDate == null) {
			lblStartDate = new JLabel("Start Date:");
			lblStartDate.setHorizontalAlignment(SwingConstants.LEFT);
			lblStartDate.setForeground(Color.decode("#525252"));
		}
		return lblStartDate;
	}

	private JLabel getLblEndDate() {
		if (lblEndDate == null) {
			lblEndDate = new JLabel("End Date:");
			lblEndDate.setForeground(Color.decode("#525252"));
		}
		return lblEndDate;
	}

	private JPanel getPnBR1() {
		if (pnBR1 == null) {
			pnBR1 = new JPanel();
			pnBR1.setBorder(new MatteBorder(24, 1, 1, 24, (Color) new Color(255, 255, 255)));
			pnBR1.setOpaque(false);
			pnBR1.setLayout(new BoxLayout(pnBR1, BoxLayout.Y_AXIS));
			pnBR1.add(getLblStartDate());
			pnBR1.add(getDateChooser());
			pnBR1.add(getLblSeparator());
			pnBR1.add(getLblEndDate());
			pnBR1.add(getDateChooser2());
		}
		return pnBR1;
	}

	public static long getDateDiff(Date date1, Date date2) {
		TimeUnit timeUnit = TimeUnit.DAYS;
		long diffInMillies = date2.getTime() - date1.getTime();
		return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
	}

	private JDateChooser getDateChooser() {
		if (dateChooser == null) {
			dateChooser = new JDateChooser();
			dateChooser.addPropertyChangeListener(new PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent evt) {
					try {
						long difference = getDateDiff(dateChooser.getDate(), dateChooser2.getDate());
						//if (difference > 0) {
							setProductDates();
							textField1.setText(String.valueOf(difference));
							displayPrice();
						//}
					} catch (Exception e) {

					}
				}
			});
			dateChooser.setMinSelectableDate(new Date());
			dateChooser.setBackground(Color.WHITE);
		}
		return dateChooser;
	}

	private JDateChooser getDateChooser2() {
		if (dateChooser2 == null) {
			dateChooser2 = new JDateChooser();
			dateChooser2.addPropertyChangeListener(new PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent evt) {
					try {
						long difference = getDateDiff(dateChooser.getDate(), dateChooser2.getDate());
						//if (difference > 0) {
							setProductDates();
							textField1.setText(String.valueOf(difference));
							displayPrice();
						//}
					} catch (Exception e) {

					}
				}
			});
			dateChooser2.setMinSelectableDate(new Date());
			dateChooser2.setBackground(Color.WHITE);
		}
		return dateChooser2;
	}

	private JPanel getPnBookLeft1() {
		if (pnBookLeft1 == null) {
			pnBookLeft1 = new JPanel();
			pnBookLeft1.setOpaque(false);
			pnBookLeft1.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		}
		return pnBookLeft1;
	}

	private JPanel getPnBookLeft2() {
		if (pnBookLeft2 == null) {
			pnBookLeft2 = new JPanel();
			pnBookLeft2.setOpaque(false);
			pnBookLeft2.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		}
		return pnBookLeft2;
	}

	private JPanel getPnBookLeft3() {
		if (pnBookLeft3 == null) {
			pnBookLeft3 = new JPanel();
			pnBookLeft3.setBorder(new MatteBorder(1, 5, 1, 1, (Color) Color.WHITE));
			pnBookLeft3.setOpaque(false);
		}
		return pnBookLeft3;
	}

	private JPanel getPnAddToCart() {
		if (pnAddToCart == null) {
			pnAddToCart = new JPanel();
			pnAddToCart.setBorder(new MatteBorder(1, 40, 15, 40, (Color) new Color(255, 255, 255)));
			pnAddToCart.setBackground(Color.WHITE);
			pnAddToCart.setLayout(new BorderLayout(0, 0));
			//pnAddToCart.add(getLblAddToCart(), BorderLayout.SOUTH);
			pnAddToCart.add(getLblPrice(), BorderLayout.EAST);
			pnAddToCart.add(getBtnAddToCart(), BorderLayout.SOUTH);
		}
		return pnAddToCart;
	}

//	private JLabel getLblAddToCart() {
//		if (lblAddToCart == null) {
//			lblAddToCart = new JLabel("Add to cart");
//			lblAddToCart.setHorizontalAlignment(SwingConstants.CENTER);
//			lblAddToCart.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					try {
//						setPeople();
//					} catch (NumberFormatException e1) {
//						JOptionPane.showMessageDialog(null, "You must book for at least one night.");
//						// JOptionPane.showMessageDialog(null, "You must book for at least one night.",
//						// null, JOptionPane.ERROR_MESSAGE, null);
//					} catch (ZeroPeopleException e1) {
//						JOptionPane.showMessageDialog(null, "You must book for at least one person.");
//					} catch (NoVacancyException e1) {
//						JOptionPane.showMessageDialog(null,
//								"The number of people you entered is greater than the capacity.");
//					} catch (ZeroNightsException e1) {
//						JOptionPane.showMessageDialog(null, "You must book for at least one night.");
//					}
//
//					try {
//						setProductDates();
//					} catch (NullDateException e1) {
//						JOptionPane.showMessageDialog(null, "You must enter the dates!");
//					}
//
//					if (product.canBeOrdered()) {
//						contenedor.getAgency().addToOrder(product);
//						JOptionPane.showMessageDialog(null, "Your purchase was made successfully. Thank You!");
//					}
//					System.out.println(contenedor.getAgency().getOrder());
//				}
//			});
//			lblAddToCart.setFont(new Font("Lucida Grande", Font.BOLD, 14));
//			lblAddToCart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			lblAddToCart.setForeground(Color.WHITE);
//			lblAddToCart.setHorizontalTextPosition(JLabel.CENTER);
//		}
//		return lblAddToCart;
//	}
	

	private void setPeople()
			throws ZeroPeopleException, NoVacancyException, NumberFormatException, ZeroNightsException {

		switch (productType) {
		case ACC:
			((Accommodation) product).setPeople((int) getSpinner1().getValue());
			((Accommodation) product).setNights(Integer.parseInt(getTF1().getText()));
			if(((Accommodation) product).isHotel()) {
				setBreakfast();
			}
			break;
		case PACK:
			((Package) product).setAdults((int) getSpinner1().getValue());
			((Package) product).setChildren((int) getSpinner2().getValue());
			break;
		case TICKET:
			((Ticket) product).setAdults((int) getSpinner1().getValue());
			((Ticket) product).setChildren((int) getSpinner2().getValue());
			break;
		}

	}
	
	private void setBreakfast() {
		((Accommodation) product).setBreakfast(getChckbxBreakfast().isSelected());
	}

	private void setProductDates() throws NullDateException {
		Date date1 = dateChooser.getDate();
		Date date2 = dateChooser2.getDate();
		switch (productType) {
		case ACC:
			((Accommodation) product).setDates(date1, date2);
			break;
		case PACK:
			((Package) product).setDate(date1);
			break;
		case TICKET:
			((Ticket) product).setDates(date1, date2);
			break;
		}
	}

	private JPanel getPnDescriptionTop() {
		if (pnDescriptionTop == null) {
			pnDescriptionTop = new JPanel();
			pnDescriptionTop.setOpaque(false);
			pnDescriptionTop.setBorder(new MatteBorder(1, 10, 1, 1, Color.decode("#FFF9ED")));
			pnDescriptionTop.setLayout(new BorderLayout(0, 0));
			pnDescriptionTop.add(getPnRating(), BorderLayout.EAST);
			pnDescriptionTop.add(getLblProductType(), BorderLayout.WEST);
		}
		return pnDescriptionTop;
	}

	private JPanel getPnRating() {
		if (pnRating == null) {
			pnRating = new JPanel();
			pnRating.setOpaque(false);
		}
		return pnRating;
	}

	private JPanel getPnDescriptionCenter() {
		if (pnDescriptionCenter == null) {
			pnDescriptionCenter = new JPanel();
			pnDescriptionCenter.setBorder(new MatteBorder(20, 10, 1, 1, Color.decode("#FFF9ED")));
			pnDescriptionCenter.setBackground(Color.decode("#FFF9ED"));
			pnDescriptionCenter.setLayout(new BorderLayout(0, 0));
			pnDescriptionCenter.add(getLblTitle(), BorderLayout.NORTH);
			pnDescriptionCenter.add(getTaDescription(), BorderLayout.CENTER);
			pnDescriptionCenter.add(getPnProductImg(), BorderLayout.WEST);
		}
		return pnDescriptionCenter;
	}

	private JLabel getLblProductType() {
		if (lblProductType == null) {
			lblProductType = new JLabel("");
			lblProductType.setForeground(Color.decode("#525252"));
			lblProductType.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		}
		return lblProductType;
	}

	private JTextArea getTaDescription() {
		if (taDescription == null) {
			taDescription = new JTextArea();
			taDescription.setBorder(new MatteBorder(1, 20, 1, 1, Color.decode("#FFF9ED")));
			taDescription.setEditable(false);
			taDescription.setLineWrap(true);
			taDescription.setWrapStyleWord(true);
			taDescription.setColumns(30);
			taDescription.setBackground(Color.decode("#FFF9ED"));
			taDescription.setForeground(Color.decode("#525252"));
		}
		return taDescription;
	}

	private JLabel getLblSeparator() {
		if (lblSeparator == null) {
			lblSeparator = new JLabel("");
			lblSeparator.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/separator.png")));
		}
		return lblSeparator;
	}

	private JLabel getLblPrice() {
		if (lblPrice == null) {
			lblPrice = new JLabel("0.0\u20AC");
			lblPrice.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		}
		return lblPrice;
	}

	private void displayPrice() {
		lblPrice.setText(String.valueOf(product.getFinalPrice()) + "�");
	}

	private JLabel getLblProductImg() {
		if (lblProductImg == null) {
			lblProductImg = new JLabel("");

		}
		return lblProductImg;
	}

	private JPanel getPnProductImg() {
		if (pnProductImg == null) {
			pnProductImg = new JPanel();
			pnProductImg.add(getLblProductImg());
			pnProductImg.setOpaque(false);
		}
		return pnProductImg;
	}
	
	private JButton getBtnCart() {
		if (btnCart == null) {
			btnCart = new JButton("");
			btnCart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnCart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("cart");
				}
			});
			btnCart.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/cart.png")));
			btnCart.setOpaque(false);
			btnCart.setContentAreaFilled(false);
			btnCart.setBorderPainted(false);
		}
		return btnCart;
	}
	private JButton getBtnHome() {
		if (btnHome == null) {
			btnHome = new JButton("");
			btnHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnHome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("welcome");
				}
			});
			btnHome.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/home.png")));
			btnHome.setOpaque(false);
			btnHome.setContentAreaFilled(false);
			btnHome.setBorderPainted(false);
		}
		return btnHome;
	}
	
	private JButton getBtnAddToCart() {
		if (btnAddToCart == null) {
			btnAddToCart = new JButton("Add to cart");
			btnAddToCart.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnAddToCart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						setPeople();
					} catch (NumberFormatException e1) {
						JOptionPane.showMessageDialog(null, "You must book for at least one night.");
						// JOptionPane.showMessageDialog(null, "You must book for at least one night.",
						// null, JOptionPane.ERROR_MESSAGE, null);
					} catch (ZeroPeopleException e1) {
						JOptionPane.showMessageDialog(null, "You must book for at least one person.");
					} catch (NoVacancyException e1) {
						JOptionPane.showMessageDialog(null,
								"The number of people you entered is greater than the capacity.");
					} catch (ZeroNightsException e1) {
						JOptionPane.showMessageDialog(null, "You must book for at least one night.");
					}

					try {
						setProductDates();
					} catch (NullDateException e1) {
						JOptionPane.showMessageDialog(null, "You must enter the dates!");
					}

					if (product.canBeOrdered()) {
						//contenedor.getAgency().addToOrder(product);
						contenedor.getAgency().addToOrder(copyProduct(product));
						JOptionPane.showMessageDialog(null, "Your purchase was made successfully. Thank You!");
					}
					System.out.println(contenedor.getAgency().getOrder());
				}
			});
			btnAddToCart.setFont(new Font("Lucida Grande", Font.BOLD, 14));
			btnAddToCart.setForeground(Color.WHITE);
			btnAddToCart.setHorizontalTextPosition(SwingConstants.CENTER);
			btnAddToCart.setOpaque(false);
			btnAddToCart.setContentAreaFilled(false);
			btnAddToCart.setBorderPainted(false);
			btnAddToCart.setBorder(null);
		}
		return btnAddToCart;
	}
	
	private Product copyProduct(Product p) {
		switch(productType) {
		case ACC:
			return new Accommodation((Accommodation)p);
		case TICKET:
			return new Ticket((Ticket)p);
		case PACK:
			return new Package((Package)p);
		}
		return null;
	}
	
	private JCheckBox getChckbxBreakfast() {
		if (chckbxBreakfast == null) {
			chckbxBreakfast = new JCheckBox("Breakfast");
			chckbxBreakfast.setOpaque(false);
			chckbxBreakfast.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					try {
						setBreakfast();
						displayPrice();
					}catch(Exception ex) {
						
					}
				}
			});
		}
		return chckbxBreakfast;
	}
	
}
