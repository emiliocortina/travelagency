package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;

import logic.Accommodation;
import logic.Package;
import logic.Product;
import logic.ProductType;
import logic.Ticket;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CardOrdered extends JPanel {

	private JPanel pnDescription;
	private JPanel pnExtra;
	private JLabel lblNewLabel;
	private JPanel pnImg;
	private JLabel lblTitle;

	private Product product;

	private ProductType productType;
	private JPanel mainPanel;
	private JPanel pnEdit;
	private JPanel pnPrice;
	private JLabel lblPrice;
	// private JLabel lblEdit;
	// private JLabel lblRemove;
	private JPanel subPnEdit;
	private JButton btnRemove;
	private JButton btnEdit;
	private CartScreen cart;

	public CardOrdered(Product product, ProductType productType, CartScreen cart) {
		//this.product = product;
		switch(productType) {
		case ACC:
			this.product= new Accommodation((Accommodation)product);
			break;
		case TICKET:
			this.product= new Ticket((Ticket)product);
			break;
		case PACK:
			this.product= new Package((Package)product);
			break;
		}
		
		this.productType = productType;
		this.cart = cart;

		setBorder(new MatteBorder(20, 100, 10, 100, Color.decode("#FFF9ED")));
		setBackground(Color.WHITE);
		setLayout(new CardLayout(0, 0));
		add(getMainPanel(), "name_980101516031");
		this.setOpaque(false);
	}

	private JPanel getPnDescription() {
		if (pnDescription == null) {
			pnDescription = new JPanel();
			pnDescription.setBorder(new MatteBorder(10, 1, 10, 1, (Color) Color.WHITE));
			pnDescription.setOpaque(false);
			pnDescription.setLayout(new BoxLayout(pnDescription, BoxLayout.Y_AXIS));
			pnDescription.add(getLblTitle());

			switch (productType) {
			case ACC:
				pnDescription.add(getLblDescription("Type: " + ((Accommodation) product).getType() + "."));
				pnDescription.add(getLblDescription("Theme Park: " + product.getPark().getName() + "."));
				pnDescription
						.add(getLblDescription("Location: " + product.getCity() + ", " + product.getCountry() + "."));
				pnDescription.add(getLblDescription("People: " + ((Accommodation) product).getPeople() + "."));
				if (((Accommodation) product).isHotel()) {
					pnDescription
							.add(getLblDescription("Breakfast: " + ((Accommodation) product).getBreakfast() + "."));
				}
				pnDescription.add(getLblDescription("From: " + ((Accommodation) product).getStartingDate() + " to "
						+ ((Accommodation) product).getEndingDate() + "."));
				break;
			case PACK:
				pnDescription
						.add(getLblDescription("Accommodation: " + ((Package) product).getAccommodation().getName()));
				pnDescription.add(getLblDescription("Theme Park: " + product.getPark().getName() + "."));
				pnDescription
						.add(getLblDescription("Location: " + product.getCity() + ", " + product.getCountry() + "."));
				pnDescription.add(getLblDescription("Adults: " + ((Package) product).getAdults()));
				pnDescription.add(getLblDescription("Children: " + ((Package) product).getChildren()));
				pnDescription.add(getLblDescription("From: " + ((Package) product).getStartingDate() + " to "
						+ ((Package) product).getEndingDate() + "."));

				break;
			case TICKET:
				pnDescription.add(getLblDescription("Theme Park: " + product.getPark().getName() + "."));
				pnDescription
						.add(getLblDescription("Location: " + product.getCity() + ", " + product.getCountry() + "."));
				pnDescription.add(getLblDescription("Adults: " + ((Ticket) product).getAdults() + "."));
				pnDescription.add(getLblDescription("Children: " + ((Ticket) product).getChildren() + "."));
				pnDescription.add(getLblDescription("From: " + ((Ticket) product).getStartingDate() + " to "
						+ ((Ticket) product).getEndingDate() + "."));
				
				break;
			}

		}
		return pnDescription;
	}

	private JLabel getLblDescription(String text) {
		JLabel newLabel = new JLabel(text); // #95989A
		newLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		newLabel.setForeground(Color.decode("#95989A"));
		return newLabel;
	}

	private JPanel getPnExtra() {
		if (pnExtra == null) {
			pnExtra = new JPanel();
			pnExtra.setBorder(new MatteBorder(8, 0, 15, 15, (Color) new Color(255, 255, 255)));
			pnExtra.setOpaque(false);
			pnExtra.setLayout(new BorderLayout(0, 0));
			pnExtra.add(getPnEdit(), BorderLayout.NORTH);
			pnExtra.add(getPnPrice(), BorderLayout.SOUTH);

			switch (productType) {
			case ACC:

			}

		}
		return pnExtra;
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("");
			lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
			lblNewLabel.setHorizontalTextPosition(SwingConstants.LEFT);

			switch (productType) {
			case PACK:
				lblNewLabel.setIcon(new ImageIcon(CardPanel.class.getResource("/img/pack.png")));
				break;
			case ACC:
				lblNewLabel.setIcon(new ImageIcon(CardPanel.class.getResource("/img/accommodationIcon.png")));
				break;
			case TICKET:
				lblNewLabel.setIcon(new ImageIcon(CardPanel.class.getResource("/img/park.png")));
				break;
			default:
				lblNewLabel.setIcon(new ImageIcon(CardPanel.class.getResource("/img/park.png")));
				break;
			}

			try {
				lblNewLabel.setIcon(MainWindow.resizeImageIcon(("/img/products/" + product.getJpg()), 120, 120));
			} catch (Exception e) {
				//System.out.println("Specific image not found for: " + product.getName());
			}

		}
		return lblNewLabel;
	}

	private JPanel getPnImg() {
		if (pnImg == null) {
			pnImg = new JPanel();
			pnImg.setLayout(new BorderLayout(0, 0));
			pnImg.add(getLblNewLabel());
			pnImg.setOpaque(false);
			pnImg.setBorder(new MatteBorder(5, 5, 5, 20, (Color) new Color(255, 255, 255)));

		}
		return pnImg;
	}

	private JLabel getLblTitle() {
		if (lblTitle == null) {
			lblTitle = new JLabel("Title");
			lblTitle.setForeground(Color.BLACK);
			lblTitle.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
			lblTitle.setText(product.getName());
		}
		return lblTitle;
	}

	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			mainPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
			mainPanel.setBackground(Color.WHITE);
			mainPanel.setLayout(new BorderLayout(0, 0));
			mainPanel.add(getPnImg(), BorderLayout.WEST);
			mainPanel.add(getPnDescription(), BorderLayout.CENTER);
			mainPanel.add(getPnExtra(), BorderLayout.EAST);
		}
		return mainPanel;
	}

	private JPanel getPnEdit() {
		if (pnEdit == null) {
			pnEdit = new JPanel();
			pnEdit.setBorder(new MatteBorder(1, 1, 10, 1, (Color) Color.WHITE));
			pnEdit.setOpaque(false);
			pnEdit.setLayout(new BorderLayout(0, 0));
			pnEdit.add(getSubPnEdit(), BorderLayout.EAST);

		}
		return pnEdit;
	}

	private JLabel getLblEmptyStar() {
		JLabel emptyStar = new JLabel();
		emptyStar.setIcon(new ImageIcon(CardPanel.class.getResource("/img/emptyStar.png")));
		return emptyStar;
	}

	private JLabel getLblFilledStar() {
		JLabel filledStar = new JLabel();
		filledStar.setIcon(new ImageIcon(CardPanel.class.getResource("/img/filledStar.png")));
		return filledStar;
	}

	private JPanel getPnPrice() {
		if (pnPrice == null) {
			pnPrice = new JPanel();
			pnPrice.setOpaque(false);
			pnPrice.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			pnPrice.add(getLblPrice());
		}
		return pnPrice;
	}

	private JLabel getLblPrice() {
		if (lblPrice == null) {
			lblPrice = new JLabel("");
			lblPrice.setText("Total Price: " + product.getFinalPrice() + "�");
			lblPrice.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		}
		return lblPrice;
	}

	// public void addRemoveListenerToCard(MouseListener listener) {
	// if (mainPanel != null) {
	// mainPanel.addMouseListener(listener);
	// }
	// }

	public String getCode() {
		return product.getCode();
	}

	public Product getProduct() {
		return product;
	}

	public ProductType getProductType() {
		return productType;
	}

	// private JLabel getLblEdit() {
	// if (lblEdit == null) {
	// lblEdit = new JLabel("Edit");
	// lblEdit.setForeground(Color.decode("#95989A"));
	// lblEdit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	// lblEdit.setIcon(new
	// ImageIcon(CardOrdered.class.getResource("/img/edit.png")));
	// lblEdit.setVerticalTextPosition(SwingConstants.BOTTOM);
	// lblEdit.setHorizontalTextPosition(SwingConstants.CENTER);
	// lblEdit.setHorizontalAlignment(SwingConstants.CENTER);
	// }
	// return lblEdit;
	// }
	// private JLabel getLblRemove() {
	// if (lblRemove == null) {
	// lblRemove = new JLabel("Remove");
	// lblRemove.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	// lblRemove.setForeground(Color.decode("#95989A"));
	// lblRemove.setVerticalAlignment(SwingConstants.TOP);
	// lblRemove.setIcon(new
	// ImageIcon(CardOrdered.class.getResource("/img/bin.png")));
	// lblRemove.setVerticalTextPosition(SwingConstants.BOTTOM);
	// lblRemove.setHorizontalTextPosition(SwingConstants.CENTER);
	// lblRemove.setHorizontalAlignment(SwingConstants.CENTER);
	// }
	// return lblRemove;
	// }

	private JButton getBtnRemove() {
		if (btnRemove == null) {
			btnRemove = new JButton("Remove");
			btnRemove.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cart.removeProduct(product);
				}
			});
			btnRemove.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnRemove.setForeground(Color.decode("#95989A"));
			btnRemove.setVerticalAlignment(SwingConstants.TOP);
			btnRemove.setIcon(new ImageIcon(CardOrdered.class.getResource("/img/bin.png")));
			btnRemove.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnRemove.setHorizontalTextPosition(SwingConstants.CENTER);
			btnRemove.setHorizontalAlignment(SwingConstants.CENTER);
			btnRemove.setOpaque(false);
			btnRemove.setContentAreaFilled(false);
			btnRemove.setBorderPainted(false);
		}
		return btnRemove;
	}

	private JButton getBtnEdit() {
		if (btnEdit == null) {
			btnEdit = new JButton("Edit");
			btnEdit.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cart.createEditDialog(product);
				}
			});
			btnEdit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnEdit.setForeground(Color.decode("#95989A"));
			btnEdit.setVerticalAlignment(SwingConstants.TOP);
			btnEdit.setIcon(new ImageIcon(CardOrdered.class.getResource("/img/edit.png")));
			btnEdit.setVerticalTextPosition(SwingConstants.BOTTOM);
			btnEdit.setHorizontalTextPosition(SwingConstants.CENTER);
			btnEdit.setHorizontalAlignment(SwingConstants.CENTER);
			btnEdit.setOpaque(false);
			btnEdit.setContentAreaFilled(false);
			btnEdit.setBorderPainted(false);
		}
		return btnEdit;
	}

	private JPanel getSubPnEdit() {
		if (subPnEdit == null) {
			subPnEdit = new JPanel();
			subPnEdit.add(getBtnEdit());
			// subPnEdit.add(getLblRemove());
			subPnEdit.add(getBtnRemove());
			subPnEdit.setOpaque(false);

		}
		return subPnEdit;
	}
}
