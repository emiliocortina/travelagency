package gui;

import javax.swing.JPanel;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import logic.*;
import logic.Package;

import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.CardLayout;
import javax.swing.border.BevelBorder;
import java.awt.Cursor;

public class CardPanel extends JPanel {
	private JPanel pnDescription;
	private JPanel pnExtra;
	private JLabel lblImg;
	private JPanel pnImg;
	private JLabel lblTitle;

	private Product product;



	private ProductType productType;
	private JPanel mainPanel;
	private JPanel pnRating;
	private JPanel pnPrice;
	private JLabel lblPrice;

	
	
	public CardPanel(Product product, ProductType productType) {
		//this.product = product;
		switch(productType) {
		case ACC:
			this.product= new Accommodation((Accommodation)product);
			break;
		case TICKET:
			this.product= new Ticket((Ticket)product);
			break;
		case PACK:
			this.product= new Package((Package)product);
			break;
		}
		
		this.productType = productType;

		setBorder(new MatteBorder(20, 100, 10, 100, Color.decode("#FFF9ED")));
		setBackground(Color.WHITE);
		setLayout(new CardLayout(0, 0));
		add(getMainPanel(), "name_980101516031");
		this.setOpaque(false);
	}

	private JPanel getPnDescription() {
		if (pnDescription == null) {
			pnDescription = new JPanel();
			pnDescription.setBorder(new MatteBorder(10, 1, 10, 1, (Color) Color.WHITE));
			pnDescription.setOpaque(false);
			pnDescription.setLayout(new BoxLayout(pnDescription, BoxLayout.Y_AXIS));
			pnDescription.add(getLblTitle());
			
			if(product.getPark().isPromoted()) {
				pnDescription.add(getLblDescription("This product is 20% off!"));
			}
			
			
			switch (productType) {
			case ACC:
				pnDescription.add(getLblDescription("Type: " + ((Accommodation) product).getType() + "."));
				pnDescription.add(getLblDescription("Theme Park: " + product.getPark().getName() + "."));
				pnDescription.add(getLblDescription("Location: " + product.getCity()+", "+product.getCountry() + "."));
				
				if (!(((Accommodation) product).isHotel())) {
					pnDescription.add(getLblDescription("Capacity: " + ((Accommodation) product).getCapacity() + "."));
					pnDescription.add(getLblDescription(
							"Price (per night): " + ((Accommodation) product).getDisplayedPrice() + "�."));
				} else {
					pnDescription.add(getLblDescription(
							"Price (per person and night): " + ((Accommodation) product).getDisplayedPrice() + "�."));
				}
				break;
			case PACK:
				pnDescription
						.add(getLblDescription("Accommodation: " + ((Package) product).getAccommodation().getName()));
				pnDescription.add(getLblDescription("Theme Park: " + product.getPark().getName() + "."));
				pnDescription.add(getLblDescription("Location: " + product.getCity()+", "+product.getCountry() + "."));
				pnDescription
				.add(getLblDescription("Length: " + ((Package) product).getLength()+" days."));
				break;
			case TICKET:
				pnDescription.add(getLblDescription("Theme Park: " + product.getPark().getName() + "."));
				pnDescription.add(getLblDescription("Location: " + product.getCity()+", "+product.getCountry() + "."));
				pnDescription.add(getLblDescription("Adult price: " + ((Ticket) product).getAdultPrice() + "�"));
				pnDescription.add(getLblDescription("Child price: " + ((Ticket) product).getChildrenPrice() + "�"));
				break;
			}

		}
		return pnDescription;
	}

	private JLabel getLblDescription(String text) {
		JLabel newLabel = new JLabel(text); // #95989A
		newLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		newLabel.setForeground(Color.decode("#95989A"));
		return newLabel;
	}

	private JPanel getPnExtra() {
		if (pnExtra == null) {
			pnExtra = new JPanel();
			pnExtra.setBorder(new MatteBorder(8, 0, 15, 15, (Color) new Color(255, 255, 255)));
			pnExtra.setOpaque(false);
			pnExtra.setLayout(new BorderLayout(0, 0));
			pnExtra.add(getPnRating(), BorderLayout.NORTH);
			pnExtra.add(getPnPrice(), BorderLayout.SOUTH);

			switch (productType) {
			case ACC:

			}

		}
		return pnExtra;
	}

	private JLabel getLblImg() {
		if (lblImg == null) {
			lblImg = new JLabel("");
			lblImg.setHorizontalAlignment(SwingConstants.LEFT);
			lblImg.setHorizontalTextPosition(SwingConstants.LEFT);

			switch (productType) {
			case PACK:
				lblImg.setIcon(new ImageIcon(CardPanel.class.getResource("/img/pack.png")));
				break;
			case ACC:
				lblImg.setIcon(new ImageIcon(CardPanel.class.getResource("/img/accommodationIcon.png")));
				break;
			case TICKET:
				lblImg.setIcon(new ImageIcon(CardPanel.class.getResource("/img/park.png")));
				break;
			default:
				lblImg.setIcon(new ImageIcon(CardPanel.class.getResource("/img/park.png")));
				break;
			}

			try {
				lblImg.setIcon(MainWindow.resizeImageIcon("/img/products/" + product.getJpg(), 120, 120));
			} catch (Exception e) {
				//System.out.println("Specific image not found for: " + product.getName());
			}

		}
		return lblImg;
	}

	private JPanel getPnImg() {
		if (pnImg == null) {
			pnImg = new JPanel();
			pnImg.setLayout(new BorderLayout(0, 0));
			pnImg.add(getLblImg());
			pnImg.setOpaque(false);
			pnImg.setBorder(new MatteBorder(5, 5, 5, 20, (Color) new Color(255, 255, 255)));

		}
		return pnImg;
	}

	private JLabel getLblTitle() {
		if (lblTitle == null) {
			lblTitle = new JLabel("Title");
			lblTitle.setForeground(Color.BLACK);
			lblTitle.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
			lblTitle.setText(product.getName());
		}
		return lblTitle;
	}

	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			mainPanel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
			mainPanel.setBackground(Color.WHITE);
			mainPanel.setLayout(new BorderLayout(0, 0));
			mainPanel.add(getPnImg(), BorderLayout.WEST);
			mainPanel.add(getPnDescription(), BorderLayout.CENTER);
			mainPanel.add(getPnExtra(), BorderLayout.EAST);
		}
		return mainPanel;
	}

	private JPanel getPnRating() {
		if (pnRating == null) {
			pnRating = new JPanel();
			pnRating.setOpaque(false);
			pnRating.setLayout(new GridLayout(0, 5, 0, 0));
			if (productType.equals(ProductType.ACC)) {
				// Display Stars
				for (int i = 0; i < 5; i++) {
					if (i < ((Accommodation) product).getCategory()) {
						pnRating.add(getLblFilledStar());
					} else {
						pnRating.add(getLblEmptyStar());
					}
				}
			}
		}
		return pnRating;
	}

	private JLabel getLblEmptyStar() {
		JLabel emptyStar = new JLabel();
		emptyStar.setIcon(new ImageIcon(CardPanel.class.getResource("/img/emptyStar.png")));
		return emptyStar;
	}

	private JLabel getLblFilledStar() {
		JLabel filledStar = new JLabel();
		filledStar.setIcon(new ImageIcon(CardPanel.class.getResource("/img/filledStar.png")));
		return filledStar;
	}

	private JPanel getPnPrice() {
		if (pnPrice == null) {
			pnPrice = new JPanel();
			pnPrice.setOpaque(false);
			pnPrice.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			pnPrice.add(getLblPrice());
		}
		return pnPrice;
	}

	private JLabel getLblPrice() {
		if (lblPrice == null) {
			lblPrice = new JLabel("");
			lblPrice.setText("Price from: " + product.getDisplayedPrice() + "�");
			lblPrice.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		}
		return lblPrice;
	}

	public void addListenerToCard(MouseListener listener) {
		if (mainPanel != null) {
			mainPanel.addMouseListener(listener);
		}
	}

	public String getCode() {
		return product.getCode();
	}

	public Product getProduct() {
		return product;
	}

	public ProductType getProductType() {
		return productType;
	}
}
