package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;

import logic.Accommodation;
import logic.Product;
import java.awt.Font;

public class CartScreen extends JPanel {

	private MainWindow contenedor;
	private JPanel rightButtons;
	private JPanel navBar;
	private JLabel lblTitle;
	private JLabel lblHome;
	private JScrollPane scrollPane;
	private JPanel panel;
	private JPanel panel_1;
	// private CardListener cardListener = new CardListener();
	private JPanel pnCenter;
	private JPanel cartControls;
	private JPanel pnTotalPrice;
	private JLabel lblTotalPrice;
	private JButton btnHome;
	private JButton btnDeleteOrder;
	private JButton btnPayment;
	private EditProductDialog editDialog;

	public CartScreen(MainWindow container) {
		setBackground(Color.decode("#FFF9ED"));
		setLayout(new BorderLayout(0, 0));
		this.contenedor = container;
		add(getNavBar(), BorderLayout.NORTH);
		add(getPnCenter(), BorderLayout.CENTER);
	}

	public void representCart() {
		panel_1.removeAll();
		representProducts();
		lblTotalPrice.setText(String.valueOf(contenedor.getAgency().getTotalPrice()) + "�");
	}

	private JPanel getRightButtons() {
		if (rightButtons == null) {
			rightButtons = new JPanel();
			FlowLayout fl_rightButtons = (FlowLayout) rightButtons.getLayout();
			fl_rightButtons.setHgap(25);
			fl_rightButtons.setAlignment(FlowLayout.RIGHT);
			// panel.setBackground(Color.decode("#007396"));
			rightButtons.setOpaque(false);
			rightButtons.add(getBtnHome());
		}
		return rightButtons;
	}

	private JPanel getNavBar() {
		if (navBar == null) {
			navBar = new JPanel();
			navBar.setLayout(new BorderLayout(0, 0));
			navBar.add(getLblTitle(), BorderLayout.CENTER);
			navBar.add(getRightButtons(), BorderLayout.EAST);
			navBar.setBackground(Color.decode("#414141"));
		}
		return navBar;
	}

	private JLabel getLblTitle() {
		if (lblTitle == null) {
			lblTitle = new JLabel("");
			lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
			lblTitle.setIcon(new ImageIcon(CartScreen.class.getResource("/img/cartTitle.png")));
		}
		return lblTitle;
	}



	private JScrollPane getScrollPane_1() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBorder(null);
			scrollPane.getViewport().setOpaque(false);
			scrollPane.setOpaque(false);
			scrollPane.setViewportView(getPanel_1_1());
			scrollPane.getVerticalScrollBar().setUnitIncrement(16);
			// scrollPane.setViewportView(getPanel_1());

		}
		return scrollPane;
	}


	private JPanel getPanel_1_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBorder(new MatteBorder(1, 50, 1, 50, Color.decode("#FFF9ED")));
			panel_1.setOpaque(false);
			panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.Y_AXIS));
			representProducts();

		}
		return panel_1;
	}

	private void representProducts() {
		int i = 0;
		for (Product p : contenedor.getAgency().getOrder()) {
			CardOrdered ordered = new CardOrdered(p, p.getProductType(), this);
			// ordered.addListenerToCard(cardListener);
			panel_1.add(ordered, p.getCode());
			i++;
		}
		if (i != 0) {
			while (i < 5) {
				panel_1.add(getEmptyPanel());
				i++;
			}
		}
	}

	private JPanel getEmptyPanel() {
		JPanel empty = new JPanel();
		empty.setOpaque(false);
		empty.setLayout(new FlowLayout());
		JLabel emptyLbl = new JLabel("");
		emptyLbl.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/bigSeparator.png")));
		empty.add(emptyLbl);
		return empty;
	}

	// private class CardListener extends MouseAdapter{
	// @Override
	// public void mouseClicked(MouseEvent e) {
	// contenedor.bookingScreen.showProduct((((CardPanel)
	// ((JPanel)e.getComponent()).getParent()).getProduct()) , (((CardPanel)
	// ((JPanel)e.getComponent()).getParent()).getProductType()));
	// contenedor.showPanel("booking");
	// }
	// }

	private JPanel getPnCenter() {
		if (pnCenter == null) {
			pnCenter = new JPanel();
			pnCenter.setOpaque(false);
			pnCenter.setLayout(new BorderLayout(0, 0));
			pnCenter.add(getScrollPane_1());
			pnCenter.add(getCartControls(), BorderLayout.NORTH);
		}
		return pnCenter;
	}

	private JPanel getCartControls() {
		if (cartControls == null) {
			cartControls = new JPanel();
			cartControls.setBorder(new MatteBorder(20, 50, 20, 50, Color.decode("#FFF9ED")));
			cartControls.setOpaque(false);
			cartControls.setLayout(new BorderLayout(0, 0));
			//cartControls.add(getLblDeleteOrder(), BorderLayout.WEST);
			cartControls.add(getBtnDeleteOrder(), BorderLayout.WEST);
			cartControls.add(getPnTotalPrice());
			cartControls.add(getBtnPayment(), BorderLayout.EAST);
		}
		return cartControls;
	}

//	private JLabel getLblDeleteOrder() {
//		if (lblDeleteOrder == null) {
//			lblDeleteOrder = new JLabel("Delete Order");
//			lblDeleteOrder.setVerticalAlignment(SwingConstants.CENTER);
//			lblDeleteOrder.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			lblDeleteOrder.setForeground(Color.WHITE);
//			lblDeleteOrder.setFont(new Font("Lucida Grande", Font.BOLD, 16));
//			lblDeleteOrder.setHorizontalTextPosition(SwingConstants.CENTER);
//			lblDeleteOrder.setIcon(new ImageIcon(CartScreen.class.getResource("/img/deleteOrderBtn.png")));
//			lblDeleteOrder.setHorizontalAlignment(SwingConstants.CENTER);
//		}
//		return lblDeleteOrder;
//	}

	private JButton getBtnDeleteOrder() {
		if (btnDeleteOrder == null) {
			btnDeleteOrder = new JButton("Delete Order");
			btnDeleteOrder.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int i = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the order?");
					if(i==JOptionPane.YES_OPTION) {
						contenedor.getAgency().resetOrder();
						representCart();
					}
				}
			});
			btnDeleteOrder.setVerticalAlignment(SwingConstants.CENTER);
			btnDeleteOrder.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnDeleteOrder.setForeground(Color.WHITE);
			btnDeleteOrder.setFont(new Font("Lucida Grande", Font.BOLD, 16));
			btnDeleteOrder.setHorizontalTextPosition(SwingConstants.CENTER);
			btnDeleteOrder.setIcon(new ImageIcon(CartScreen.class.getResource("/img/deleteOrderBtn.png")));
			btnDeleteOrder.setHorizontalAlignment(SwingConstants.CENTER);
			btnDeleteOrder.setOpaque(false);
			btnDeleteOrder.setContentAreaFilled(false);
			btnDeleteOrder.setBorderPainted(false);
		}
		return btnDeleteOrder;
	}
	
//	private JLabel getLblPayment() {
//		if (lblPayment == null) {
//			lblPayment = new JLabel("Proceed to payment");
//			lblPayment.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			lblPayment.setHorizontalTextPosition(SwingConstants.CENTER);
//			lblPayment.setForeground(Color.WHITE);
//			lblPayment.setFont(new Font("Lucida Grande", Font.BOLD, 16));
//			lblPayment.setIcon(new ImageIcon(CartScreen.class.getResource("/img/paymentBtn.png")));
//			lblPayment.setHorizontalAlignment(SwingConstants.CENTER);
//		}
//		return lblPayment;
//	}
	
	private JButton getBtnPayment() {
		if (btnPayment == null) {
			btnPayment = new JButton("Proceed to payment");
			btnPayment.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(!contenedor.getAgency().getOrder().isEmpty()) {
						contenedor.showPanel("formalize");}
					else {
						JOptionPane.showMessageDialog(null, "Order is empty.");
					}
				}
			});
			btnPayment.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnPayment.setHorizontalTextPosition(SwingConstants.CENTER);
			btnPayment.setForeground(Color.WHITE);
			btnPayment.setFont(new Font("Lucida Grande", Font.BOLD, 16));
			btnPayment.setIcon(new ImageIcon(CartScreen.class.getResource("/img/paymentBtn.png")));
			btnPayment.setHorizontalAlignment(SwingConstants.CENTER);
			btnPayment.setOpaque(false);
			btnPayment.setContentAreaFilled(false);
			btnPayment.setBorderPainted(false);
		}
		return btnPayment;
	}

	private JPanel getPnTotalPrice() {
		if (pnTotalPrice == null) {
			pnTotalPrice = new JPanel();
			pnTotalPrice.setBackground(Color.WHITE);
			pnTotalPrice.add(getLblTotalPrice());
			pnTotalPrice.setOpaque(false);
		}
		return pnTotalPrice;
	}

	private JLabel getLblTotalPrice() {
		if (lblTotalPrice == null) {
			lblTotalPrice = new JLabel("0.0�");
			lblTotalPrice.setHorizontalTextPosition(SwingConstants.CENTER);
			lblTotalPrice.setFont(new Font("Lucida Grande", Font.BOLD, 16));
			lblTotalPrice.setIcon(new ImageIcon(CartScreen.class.getResource("/img/pricePanel.png")));
			lblTotalPrice.setHorizontalAlignment(SwingConstants.CENTER);
			
		}
		return lblTotalPrice;
	}
	
	private JButton getBtnHome() {
		if (btnHome == null) {
			btnHome = new JButton("");
			btnHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnHome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("welcome");
				}
			});
			btnHome.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/home.png")));
			btnHome.setOpaque(false);
			btnHome.setContentAreaFilled(false);
			btnHome.setBorderPainted(false);
		}
		return btnHome;
	}
	
	public void removeProduct(Product p) {
		contenedor.getAgency().removeFromOrder(p);
		this.representCart();
	}
	
	public void createEditDialog(Product p) {
		editDialog = new EditProductDialog(p, this);
		editDialog.setModal(true);
		editDialog.setLocationRelativeTo(this);
		editDialog.setVisible(true);
	}
	
}
