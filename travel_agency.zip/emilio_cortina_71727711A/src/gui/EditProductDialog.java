package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.toedter.calendar.JDateChooser;

import logic.Accommodation;
import logic.NoVacancyException;
import logic.NullDateException;
import logic.Package;
import logic.Product;
import logic.Ticket;
import logic.ZeroNightsException;
import logic.ZeroPeopleException;

import java.awt.Color;

import javax.swing.AbstractButton;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class EditProductDialog extends JDialog {



	Product product;
	private JPanel panel_1;

	private JLabel lblHeader;
	private JPanel pnBookRight;
	private JPanel pnBookCenter;
	private JPanel pnBR1;
	private JPanel pnBookLeft1;
	private JPanel pnBookLeft2;
	private JPanel pnBookLeft3;
	private JPanel pnAddToCart;
	private JPanel pnBookLeft;
	private JLabel lblEndDate;
	private JLabel lblStartDate;
	private JDateChooser dateChooser2;
	private JDateChooser dateChooser;
	private JLabel lblPrice;
	private JLabel lblSeparator;
	private JButton btnAddToCart;

	private JTextField textField1;
	private JSpinner spinner2;
	private JSpinner spinner1;
	private CartScreen cart;
	private JLabel lblProductName;

	public EditProductDialog(Product product, CartScreen cart) {
		getContentPane().setBackground(Color.WHITE);
		{
			this.cart=cart;
			JPanel pnHeader = new JPanel();
			pnHeader.setBackground(Color.decode("#80CBC4"));
			getContentPane().add(pnHeader, BorderLayout.NORTH);
			pnHeader.add(getLblHeader());
		}
		getContentPane().add(getPanel_1(), BorderLayout.CENTER);
		this.product = product;
		setBounds(100, 100, 500, 650);

		
		getSpinner1().setValue(0);
		getSpinner2().setValue(0);
		getTF1().setText(null);
		getDateChooser().setDate(null);
		getDateChooser2().setDate(null);

		pnBookLeft1.removeAll();
		pnBookLeft2.removeAll();
		pnBookLeft3.removeAll();

		if(product instanceof Accommodation) {
			dateChooser2.setEnabled(true);

			pnBookLeft1.add(getIconLabel("nights.png"));
			pnBookLeft1.add(new JLabel("Nights: "));
			pnBookLeft1.add(getTF1());

			pnBookLeft2.add(getIconLabel("people.png"));
			pnBookLeft2.add(new JLabel("People: "));
			pnBookLeft2.add(getSpinner1());

			//lblAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingBlueButton.png")));
			btnAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingBlueButton.png")));
		}

		if(product instanceof Ticket) {
			dateChooser2.setEnabled(true);

			pnBookLeft1.add(getIconLabel("people.png"));
			pnBookLeft1.add(new JLabel("Adults:   "));
			pnBookLeft1.add(getSpinner1());

			pnBookLeft2.add(getIconLabel("children.png"));
			pnBookLeft2.add(new JLabel("Children: "));
			pnBookLeft2.add(getSpinner2());

			
			//lblAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
			btnAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
			
		}if(product instanceof Package) {
			dateChooser2.setEnabled(false);

			pnBookLeft1.add(getIconLabel("people.png"));
			pnBookLeft1.add(new JLabel("Adults:   "));
			pnBookLeft1.add(getSpinner1());

			pnBookLeft2.add(getIconLabel("children.png"));
			pnBookLeft2.add(new JLabel("Children: "));
			pnBookLeft2.add(getSpinner2());

			//lblAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
			btnAddToCart.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/bookingRedButton.png")));
		}
		
		getLblProductName().setText(product.getName());
		
	}

	private JPanel getPanel_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBackground(Color.WHITE);
			panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			panel_1.setLayout(new BorderLayout(0, 0));
			panel_1.add(getPnBookRight(), BorderLayout.EAST);
			panel_1.add(getPnBookLeft(), BorderLayout.WEST);
			panel_1.add(getPnAddToCart(), BorderLayout.SOUTH);
		}
		return panel_1;
	}

	private JLabel getLblHeader() {
		if (lblHeader == null) {
			lblHeader = new JLabel("");
			lblHeader.setIcon(new ImageIcon(EditProductDialog.class.getResource("/img/editProductTitle.png")));
		}
		return lblHeader;
	}

	private JPanel getPnBookRight() {
		if (pnBookRight == null) {
			pnBookRight = new JPanel();
			pnBookRight.setBackground(Color.WHITE);
			pnBookRight.setLayout(new BorderLayout(0, 0));
			pnBookRight.add(getPnBR1(), BorderLayout.NORTH);
		}
		return pnBookRight;
	}

	private JPanel getPnBookCenter() {
		if (pnBookCenter == null) {
			pnBookCenter = new JPanel();
			pnBookCenter.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
			pnBookCenter.setBackground(Color.WHITE);
			pnBookCenter.setLayout(new BorderLayout(0, 0));
			pnBookCenter.add(getPnBookRight(), BorderLayout.EAST);
			pnBookCenter.add(getPnBookLeft(), BorderLayout.WEST);
			pnBookCenter.add(getPnAddToCart(), BorderLayout.SOUTH);
		}
		return pnBookCenter;
	}

	private JPanel getPnBR1() {
		if (pnBR1 == null) {
			pnBR1 = new JPanel();
			pnBR1.setBorder(new MatteBorder(24, 1, 1, 24, (Color) new Color(255, 255, 255)));
			pnBR1.setOpaque(false);
			pnBR1.setLayout(new BoxLayout(pnBR1, BoxLayout.Y_AXIS));
			pnBR1.add(getLblStartDate());
			pnBR1.add(getDateChooser());
			pnBR1.add(getLblSeparator());
			pnBR1.add(getLblEndDate());
			pnBR1.add(getDateChooser2());
		}
		return pnBR1;
	}

	private JPanel getPnBookLeft1() {
		if (pnBookLeft1 == null) {
			pnBookLeft1 = new JPanel();
			pnBookLeft1.setOpaque(false);
			pnBookLeft1.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		}
		return pnBookLeft1;
	}

	private JPanel getPnBookLeft2() {
		if (pnBookLeft2 == null) {
			pnBookLeft2 = new JPanel();
			pnBookLeft2.setOpaque(false);
			pnBookLeft2.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		}
		return pnBookLeft2;
	}

	private JPanel getPnBookLeft3() {
		if (pnBookLeft3 == null) {
			pnBookLeft3 = new JPanel();
			pnBookLeft3.setOpaque(false);
		}
		return pnBookLeft3;
	}

	private JPanel getPnAddToCart() {
		if (pnAddToCart == null) {
			pnAddToCart = new JPanel();
			pnAddToCart.setBorder(new MatteBorder(1, 40, 15, 40, (Color) new Color(255, 255, 255)));
			pnAddToCart.setBackground(Color.WHITE);
			pnAddToCart.setLayout(new BorderLayout(0, 0));
			// pnAddToCart.add(getLblAddToCart(), BorderLayout.SOUTH);
			pnAddToCart.add(getLblPrice(), BorderLayout.EAST);
			pnAddToCart.add(getBtnAddToCart(), BorderLayout.SOUTH);
		}
		return pnAddToCart;
	}

	private JPanel getPnBookLeft() {
		if (pnBookLeft == null) {
			pnBookLeft = new JPanel();
			pnBookLeft.setBorder(new MatteBorder(24, 24, 24, 24, (Color) Color.WHITE));
			pnBookLeft.setOpaque(false);
			pnBookLeft.setLayout(new BoxLayout(pnBookLeft, BoxLayout.Y_AXIS));
			pnBookLeft.add(getLblProductName());
			pnBookLeft.add(getPnBookLeft1());
			pnBookLeft.add(getPnBookLeft2());
			pnBookLeft.add(getPnBookLeft3());
			
		}
		return pnBookLeft;
	}

	private JLabel getLblStartDate() {
		if (lblStartDate == null) {
			lblStartDate = new JLabel("Start Date:");
			lblStartDate.setHorizontalAlignment(SwingConstants.LEFT);
			lblStartDate.setForeground(Color.decode("#525252"));
		}
		return lblStartDate;
	}

	private JLabel getLblEndDate() {
		if (lblEndDate == null) {
			lblEndDate = new JLabel("End Date:");
			lblEndDate.setForeground(Color.decode("#525252"));
		}
		return lblEndDate;
	}

	public static long getDateDiff(Date date1, Date date2) {
		TimeUnit timeUnit = TimeUnit.DAYS;
		long diffInMillies = date2.getTime() - date1.getTime();
		return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
	}

	private JDateChooser getDateChooser() {
		if (dateChooser == null) {
			dateChooser = new JDateChooser();
			dateChooser.addPropertyChangeListener(new PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent evt) {
					try {
						long difference = getDateDiff(dateChooser.getDate(), dateChooser2.getDate());
						setProductDates();
						textField1.setText(String.valueOf(difference));
						displayPrice();
					} catch (Exception e) {

					}
				}
			});
			dateChooser.setMinSelectableDate(new Date());
			dateChooser.setBackground(Color.WHITE);
		}
		return dateChooser;
	}

	private JDateChooser getDateChooser2() {
		if (dateChooser2 == null) {
			dateChooser2 = new JDateChooser();
			dateChooser2.addPropertyChangeListener(new PropertyChangeListener() {
				public void propertyChange(PropertyChangeEvent evt) {
					try {
						long difference = getDateDiff(dateChooser.getDate(), dateChooser2.getDate());
						setProductDates();
						textField1.setText(String.valueOf(difference));
						displayPrice();
					} catch (Exception e) {

					}
				}
			});
			dateChooser2.setMinSelectableDate(new Date());
			dateChooser2.setBackground(Color.WHITE);
		}
		return dateChooser2;
	}

	private JLabel getLblSeparator() {
		if (lblSeparator == null) {
			lblSeparator = new JLabel("");
			lblSeparator.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/separator.png")));
		}
		return lblSeparator;
	}

	private JLabel getLblPrice() {
		if (lblPrice == null) {
			lblPrice = new JLabel("0.0�");
			lblPrice.setFont(new Font("Lucida Grande", Font.BOLD, 28));
		}
		return lblPrice;
	}

	private JButton getBtnAddToCart() {
		if (btnAddToCart == null) {
			btnAddToCart = new JButton("Finish editing");
			btnAddToCart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						setPeople();
					} catch (NumberFormatException e1) {
						JOptionPane.showMessageDialog(null, "You must book for at least one night.");
						// JOptionPane.showMessageDialog(null, "You must book for at least one night.",
						// null, JOptionPane.ERROR_MESSAGE, null);
					} catch (ZeroPeopleException e1) {
						JOptionPane.showMessageDialog(null, "You must book for at least one person.");
					} catch (NoVacancyException e1) {
						JOptionPane.showMessageDialog(null,
								"The number of people you entered is greater than the capacity.");
					} catch (ZeroNightsException e1) {
						JOptionPane.showMessageDialog(null, "You must book for at least one night.");
					}

					try {
						setProductDates();
					} catch (NullDateException e1) {
						JOptionPane.showMessageDialog(null, "You must enter the dates!");
					}

					if (product.canBeOrdered()) {
						JOptionPane.showMessageDialog(null, "Your product has been edited successfully. Thank You!");
						cart.representCart();
						dispose();
					}
				}
			});
			btnAddToCart.setFont(new Font("Lucida Grande", Font.BOLD, 14));
			btnAddToCart.setForeground(Color.WHITE);
			btnAddToCart.setHorizontalTextPosition(SwingConstants.CENTER);
			btnAddToCart.setOpaque(false);
			btnAddToCart.setContentAreaFilled(false);
			btnAddToCart.setBorderPainted(false);
			btnAddToCart.setBorder(null);
		}
		return btnAddToCart;
	}

	private void setProductDates() throws NullDateException {
		Date date1 = dateChooser.getDate();
		Date date2 = dateChooser2.getDate();

		if (product instanceof Accommodation) {
			((Accommodation) product).setDates(date1, date2);
		}

		if (product instanceof Package) {
			((Package) product).setDate(date1);
		}

		if (product instanceof Ticket) {
			((Ticket) product).setDates(date1, date2);
		}
	}

	private void setPeople()
			throws ZeroPeopleException, NoVacancyException, NumberFormatException, ZeroNightsException {

		if (product instanceof Accommodation) {
			((Accommodation) product).setPeople((int) getSpinner1().getValue());
			((Accommodation) product).setNights(Integer.parseInt(getTF1().getText()));
		}

		if (product instanceof Package) {
			((Package) product).setAdults((int) getSpinner1().getValue());
			((Package) product).setChildren((int) getSpinner2().getValue());
		}

		if (product instanceof Ticket) {
			((Ticket) product).setAdults((int) getSpinner1().getValue());
			((Ticket) product).setChildren((int) getSpinner2().getValue());
		}
	}
	
	private JSpinner getSpinner1() {
		if (spinner1 == null) {
			spinner1 = new JSpinner(new SpinnerNumberModel(0, 0, 9, 1));
			spinner1.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					try {
						setPeople();
						displayPrice();
					} catch (Exception ex) {
						System.out.println("Ni idea");
					}
				}
			});
		}
		return spinner1;
	}

	private JSpinner getSpinner2() {
		if (spinner2 == null) {
			spinner2 = new JSpinner(new SpinnerNumberModel(0, 0, 9, 1));
			spinner2.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent e) {
					try {
						setPeople();
						displayPrice();
					} catch (Exception ex) {
					}
				}
			});
		}
		return spinner2;
	}
	
	private void displayPrice() {
		lblPrice.setText(String.valueOf(product.getFinalPrice()) + "�");
	}
	
	private JTextField getTF1() {
		if (textField1 == null) {
			textField1 = new JTextField();
			textField1.setColumns(2);
			textField1.setEditable(false);
		}
		return textField1;
	}
	
	private JLabel getIconLabel(String name) {
		JLabel imgLabel = new JLabel("");
		imgLabel.setIcon(new ImageIcon(BookingScreen.class.getResource("/img/" + name)));
		return imgLabel;
	}

	private JLabel getLblProductName() {
		if (lblProductName == null) {
			lblProductName = new JLabel("");
			lblProductName.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		}
		return lblProductName;
	}
}
