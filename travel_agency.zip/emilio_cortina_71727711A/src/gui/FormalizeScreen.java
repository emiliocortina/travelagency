package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

import logic.Product;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

public class FormalizeScreen extends JPanel {

	private MainWindow contenedor;
	private JPanel rightButtons;
	private JPanel navBar;
	private JLabel lblTitle;
	private JButton btnHome;
	private JButton btnBack;
	private JPanel pnCenter;
	private JLabel lblDataTitle;
	private JPanel pnDataTitle;
	private JPanel pnData;
	private JPanel pnName;
	private JPanel pnSurname;
	private JPanel pnID;
	private JPanel pnComments;
	private JLabel lblName;
	private JTextField txtName;
	private JLabel lblSurname;
	private JTextField txtSurname;
	private JLabel lblID;
	private JTextField txtID;
	private JTextArea txtrComments;
	private JTextArea textArea;
	private JPanel pnConfirm;
	private JButton btnConfirm;
	private JPanel pnLeft;
	private JPanel pnRight;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;

	public FormalizeScreen(MainWindow container) {
		setBackground(Color.decode("#FFF9ED"));
		setLayout(new BorderLayout(0, 0));
		this.contenedor = container;
		add(getNavBar(), BorderLayout.NORTH);
		add(getPnCenter(), BorderLayout.CENTER);
		add(getPnLeft(), BorderLayout.WEST);
		add(getPnRight(), BorderLayout.EAST);
	}

	private JPanel getRightButtons() {
		if (rightButtons == null) {
			rightButtons = new JPanel();
			FlowLayout fl_rightButtons = (FlowLayout) rightButtons.getLayout();
			fl_rightButtons.setHgap(25);
			fl_rightButtons.setAlignment(FlowLayout.RIGHT);
			// panel.setBackground(Color.decode("#007396"));
			rightButtons.setOpaque(false);
			rightButtons.add(getBtnHome());
		}
		return rightButtons;
	}

	private JPanel getNavBar() {
		if (navBar == null) {
			navBar = new JPanel();
			navBar.setLayout(new BorderLayout(0, 0));
			navBar.add(getBtnBack(), BorderLayout.WEST);
			navBar.add(getLblTitle(), BorderLayout.CENTER);
			navBar.add(getRightButtons(), BorderLayout.EAST);
			navBar.setBackground(Color.decode("#414141"));
		}
		return navBar;
	}

	private JLabel getLblTitle() {
		if (lblTitle == null) {
			lblTitle = new JLabel("");
			lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
			lblTitle.setIcon(new ImageIcon(CartScreen.class.getResource("/img/formalizeTitle.png")));
		}
		return lblTitle;
	}

	private JButton getBtnHome() {
		if (btnHome == null) {
			btnHome = new JButton("");
			btnHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnHome.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("welcome");
				}
			});
			btnHome.setIcon(new ImageIcon(AccommodationsScreen.class.getResource("/img/home.png")));
			btnHome.setOpaque(false);
			btnHome.setContentAreaFilled(false);
			btnHome.setBorderPainted(false);
		}
		return btnHome;
	}

	private JButton getBtnBack() {
		if (btnBack == null) {
			btnBack = new JButton("");
			btnBack.setIcon(new ImageIcon(FormalizeScreen.class.getResource("/img/backArrow.png")));
			btnBack.setOpaque(false);
			btnBack.setContentAreaFilled(false);
			btnBack.setBorderPainted(false);
		}
		return btnBack;
	}

	private JPanel getPnCenter() {
		if (pnCenter == null) {
			pnCenter = new JPanel();
			pnCenter.setBackground(Color.WHITE);
			pnCenter.setBorder(new LineBorder(new Color(255, 249, 237), 50));
			pnCenter.setLayout(new BorderLayout(0, 0));
			pnCenter.add(getPnDataTitle(), BorderLayout.NORTH);
			pnCenter.add(getPnData(), BorderLayout.CENTER);
			pnCenter.add(getPnConfirm(), BorderLayout.SOUTH);

		}
		return pnCenter;
	}

	private JLabel getLblDataTitle() {
		if (lblDataTitle == null) {
			lblDataTitle = new JLabel("");
			lblDataTitle.setIcon(new ImageIcon(FormalizeScreen.class.getResource("/img/customerData.png")));
		}
		return lblDataTitle;
	}

	private JPanel getPnDataTitle() {
		if (pnDataTitle == null) {
			pnDataTitle = new JPanel();
			pnDataTitle.setBackground(Color.WHITE);
			pnDataTitle.setBorder(new LineBorder(Color.WHITE, 20));
			pnDataTitle.add(getLblDataTitle());
		}
		return pnDataTitle;
	}

	private JPanel getPnData() {
		if (pnData == null) {
			pnData = new JPanel();
			pnData.setBackground(Color.WHITE);
			pnData.setLayout(new BoxLayout(pnData, BoxLayout.Y_AXIS));
			pnData.add(getPnName());
			pnData.add(getPnSurname());
			pnData.add(getPnID());
			pnData.add(getPnComments());
		}
		return pnData;
	}

	private JPanel getPnName() {
		if (pnName == null) {
			pnName = new JPanel();
			pnName.setBackground(Color.WHITE);
			pnName.add(getLblName());
			pnName.add(getTxtName());
		}
		return pnName;
	}

	private JPanel getPnSurname() {
		if (pnSurname == null) {
			pnSurname = new JPanel();
			pnSurname.setBackground(Color.WHITE);
			pnSurname.add(getLblSurname());
			pnSurname.add(getTxtSurname());
		}
		return pnSurname;
	}

	private JPanel getPnID() {
		if (pnID == null) {
			pnID = new JPanel();
			pnID.setBackground(Color.WHITE);
			pnID.add(getLblID());
			pnID.add(getTxtID());
		}
		return pnID;
	}

	private JPanel getPnComments() {
		if (pnComments == null) {
			pnComments = new JPanel();
			pnComments.setBackground(Color.WHITE);
			pnComments.add(getTxtrComments());
			pnComments.add(getTextArea());
		}
		return pnComments;
	}

	private JLabel getLblName() {
		if (lblName == null) {
			lblName = new JLabel("Name:");
			lblName.setForeground(Color.decode("#95989A"));
		}
		return lblName;
	}

	private JTextField getTxtName() {
		if (txtName == null) {
			txtName = new JTextField();
			txtName.setColumns(10);
		}
		return txtName;
	}

	private JLabel getLblSurname() {
		if (lblSurname == null) {
			lblSurname = new JLabel("Surname:");
			lblSurname.setForeground(Color.decode("#95989A"));
		}
		return lblSurname;
	}

	private JTextField getTxtSurname() {
		if (txtSurname == null) {
			txtSurname = new JTextField();
			txtSurname.setColumns(10);
		}
		return txtSurname;
	}

	private JLabel getLblID() {
		if (lblID == null) {
			lblID = new JLabel("ID:");
			lblID.setForeground(Color.decode("#95989A"));
		}
		return lblID;
	}

	private JTextField getTxtID() {
		if (txtID == null) {
			txtID = new JTextField();
			txtID.setColumns(10);
		}
		return txtID;
	}

	private JTextArea getTxtrComments() {
		if (txtrComments == null) {
			txtrComments = new JTextArea();
			txtrComments.setEditable(false);
			txtrComments.setColumns(12);
			txtrComments.setLineWrap(true);
			txtrComments.setWrapStyleWord(true);
			txtrComments.setText("(Optional) Comments and/or suggestions:");
			txtrComments.setForeground(Color.decode("#95989A"));
		}
		return txtrComments;
	}

	private JTextArea getTextArea() {
		if (textArea == null) {
			textArea = new JTextArea();
			textArea.setLineWrap(true);
			textArea.setWrapStyleWord(true);
			textArea.setColumns(12);
			textArea.setRows(5);
			textArea.setBorder(new LineBorder(Color.decode("#95989A")));
			textArea.setForeground(Color.decode("#95989A"));
		}
		return textArea;
	}

	private JPanel getPnConfirm() {
		if (pnConfirm == null) {
			pnConfirm = new JPanel();
			pnConfirm.setBackground(Color.WHITE);
			pnConfirm.add(getBtnConfirm());
		}
		return pnConfirm;
	}

	private JButton getBtnConfirm() {
		if (btnConfirm == null) {
			btnConfirm = new JButton("Confirm order");
			btnConfirm.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (infoFilled()) {
						createDialog();
					} else {
						JOptionPane.showMessageDialog(null, "You must fill all the info.");
					}
				}
			});
			btnConfirm.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnConfirm.setFont(new Font("Lucida Grande", Font.BOLD, 16));
			btnConfirm.setHorizontalTextPosition(SwingConstants.CENTER);
			btnConfirm.setIcon(new ImageIcon(FormalizeScreen.class.getResource("/img/paymentBtn.png")));
			btnConfirm.setForeground(Color.WHITE);
			btnConfirm.setOpaque(false);
			btnConfirm.setContentAreaFilled(false);
			btnConfirm.setBorderPainted(false);
		}
		return btnConfirm;
	}

	private boolean infoFilled() {
		return (!getTxtName().getText().equals("") && !getTxtSurname().getText().equals("") && !getTxtID().getText().equals(""));
	}

	private void createDialog() {
		SummaryDialog sD = new SummaryDialog(contenedor,
				contenedor.getReceipt(getTxtName().getText(), getTxtSurname().getText(), getTxtID().getText()),
				getTxtID().getText());
		sD.setModal(true);
		sD.setLocationRelativeTo(this);
		sD.setVisible(true);
	}

	private JPanel getPnLeft() {
		if (pnLeft == null) {
			pnLeft = new JPanel();
			pnLeft.setOpaque(false);
			pnLeft.setBorder(new LineBorder(new Color(255, 249, 237), 60));
			pnLeft.add(getLblNewLabel());
		}
		return pnLeft;
	}

	private JPanel getPnRight() {
		if (pnRight == null) {
			pnRight = new JPanel();
			pnRight.setOpaque(false);
			pnRight.setBorder(new LineBorder(new Color(255, 249, 237), 60));
			pnRight.add(getLblNewLabel_1());
		}
		return pnRight;
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("");
			lblNewLabel.setIcon(new ImageIcon(FormalizeScreen.class.getResource("/img/bigSeparator.png")));
		}
		return lblNewLabel;
	}

	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("");
			lblNewLabel_1.setIcon(new ImageIcon(FormalizeScreen.class.getResource("/img/bigSeparator.png")));
		}
		return lblNewLabel_1;
	}
}
