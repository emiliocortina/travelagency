package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logic.Agency;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.awt.event.ActionEvent;


public class MainWindow extends JFrame {

	private JPanel contentPane;
	public CardLayout layout;

	private Agency agency;
	public BookingScreen bookingScreen;
	public CartScreen cartScreen;
	public FormalizeScreen formalizeScreen;
	
	public static final String WELCOME = "welcome";
	public static final String ACCOMMODATION = "accommodation";
	public static final String TICKET = "ticket";
	public static final String PACKAGE = "package";
	public static final String BOOKING = "booking";
	private JMenuBar menuBar;
	private JMenuItem mntmRestart;
	private JMenuItem mntmExit;
	private JMenu mnFile;
	private JSeparator separator;
	private JMenu mnHelp;
	private JMenuItem mntmContents;
	private JMenuItem mntmAbout;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
					System.out.println(frame.getContentPane().getSize());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainWindow.class.getResource("/img/appIcon.png")));
		setTitle("Peter Parker Travel Agency");
		//Creating the agency.
		agency = new Agency();
		bookingScreen = new BookingScreen(this);
		cartScreen = new CartScreen(this);
		formalizeScreen = new FormalizeScreen(this);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1279, 742);
		
		menuBar = new JMenuBar();
		menuBar.setBackground(Color.WHITE);
		setJMenuBar(menuBar);
		
		mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		mntmRestart = new JMenuItem("Restart application");
		mntmRestart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				restart();
			}
		});
		mntmRestart.setMnemonic('R');
		mnFile.add(mntmRestart);
		
		separator = new JSeparator();
		mnFile.add(separator);
		
		mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mntmExit.setMnemonic('x');
		mnFile.add(mntmExit);
		
		mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		mntmContents = new JMenuItem("Contents");
		mnHelp.add(mntmContents);
		
		mntmAbout = new JMenuItem("About");
		mnHelp.add(mntmAbout);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		System.out.println(contentPane.getWidth() + "x" + contentPane.getHeight());
		layout = new CardLayout(0, 0);
		contentPane.setLayout(layout);
		
		contentPane.add(new WelcomeScreen(this), "welcome");
		contentPane.add(new AccommodationsScreen(this), "accommodation");
		contentPane.add(new TicketsScreen(this), "ticket");
		contentPane.add(new PackagesScreen(this), "package");
		contentPane.add(bookingScreen, "booking");
		contentPane.add(cartScreen, "cart");
		contentPane.add(formalizeScreen, "formalize");
		
		loadHelp();
		
	}

	public void showPanel(String panel) {
		if (validPanel(panel)) {
			if(panel.equals("cart")) {
				cartScreen.representCart();
			}
			layout.show(contentPane, panel);
		}
	}

	public boolean validPanel(String panel) {
		// boolean b = panel.equals(panel1)....
		return true;
	}

	public Agency getAgency() {
		return agency;
	}
	
	public static final ImageIcon resizeImageIcon(String location, int width, int height) {
		// Resizing icon image
		ImageIcon icon = new ImageIcon(MainWindow.class.getResource(location));
		Image img = icon.getImage();
		Image newimg = img.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH);
		ImageIcon newIcon = new ImageIcon(newimg);
		return newIcon;
	}

	
	public String getReceipt(String customerName, String customerSurname, String customerID) {
		return agency.generateReceipt(customerName, customerSurname, customerID);
	}

	public void saveOrder(String receipt, String name) {
		agency.saveFile(receipt, name);
	}

	public void restart() {
		agency.resetOrder();
		showPanel("welcome");
		
	}
	
	private void loadHelp(){
		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/Help.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"intro", hs);
		   hb.enableHelpOnButton(mntmContents, "intro", hs);
		   //hb.enableHelp(list1, "add", hs);
		   //hb.enableHelp(slVolume, "volume", hs);
		 }
	
}
