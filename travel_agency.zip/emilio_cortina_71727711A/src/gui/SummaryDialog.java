package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SummaryDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JScrollPane scrLeft;
	private JTextArea txtaReceipt;
	private String receipt;
	private MainWindow contenedor;



	/**
	 * Create the dialog.
	 */
	public SummaryDialog(MainWindow contenedor, String receipt, String customerName) {
		this.receipt=receipt;
		this.contenedor=contenedor;
		
		getContentPane().setBackground(Color.WHITE);
		setBounds(100, 100, 450, 496);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(Color.WHITE);
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						contenedor.saveOrder(receipt, customerName);
						contenedor.restart();
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		contentPanel.setLayout(new BorderLayout(0, 0));
		contentPanel.add(getScrLeft());
		getTxtaReceipt().setText(receipt);
	}

	
	private JScrollPane getScrLeft() {
		if (scrLeft == null) {
			scrLeft = new JScrollPane();
			scrLeft.setViewportView(getTxtaReceipt());
		}
		return scrLeft;
	}
	private JTextArea getTxtaReceipt() {
		if (txtaReceipt == null) {
			txtaReceipt = new JTextArea();
			txtaReceipt.setWrapStyleWord(true);
			txtaReceipt.setEditable(false);
			txtaReceipt.setBorder(null);
			txtaReceipt.setText(receipt);
		}
		return txtaReceipt;
	}
}
