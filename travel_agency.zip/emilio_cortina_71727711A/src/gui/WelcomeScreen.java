package gui;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JSeparator;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;

public class WelcomeScreen extends JPanel {
	private JPanel accPanel;
	private JPanel packPanel;
	private JPanel mainPanel;
	private JLabel lblAccImg;
	private JLabel lblWelcome;
	private MainWindow contenedor;
	private JPanel pnBtnAcc;
	private JLabel btnAcc;
	private JLabel lblPackImg;
	private JPanel pnBtnPack;
	private JLabel btnPack;
	
	private accListener accommodationsListener = new accListener();
	private JPanel ticketsPanel;
	private JLabel lblTicketsImg;
	private JPanel panel;
	private JLabel label;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JPanel pnTitle;
	

	/**
	 * Create the panel.
	 */
	public WelcomeScreen(MainWindow container) {
		setBackground(Color.decode("#FFF2DB"));
		setLayout(new BorderLayout(0, 0));
		add(getPnTitle(), BorderLayout.NORTH);
		add(getMainPanel(), BorderLayout.CENTER);
		this.contenedor = container;

	}

	private JPanel getAccPanel() {
		if (accPanel == null) {
			accPanel = new JPanel();
			accPanel.setBorder(new LineBorder(new Color(255, 242, 219), 20));
			accPanel.setBackground(Color.decode("#FFF2DB"));
			accPanel.setLayout(new BorderLayout(0, 0));
			accPanel.add(getLblAccImg(), BorderLayout.CENTER);
			accPanel.add(getPnBtnAcc(), BorderLayout.SOUTH);
		}
		return accPanel;
	}
	private JPanel getPackPanel() {
		if (packPanel == null) {
			packPanel = new JPanel();
			packPanel.setBorder(new LineBorder(Color.decode("#FFF2DB"), 20));
			packPanel.setOpaque(false);
			packPanel.setLayout(new BorderLayout(0, 0));
			packPanel.add(getLblPackImg(), BorderLayout.CENTER);
			packPanel.add(getPnBtnPack(), BorderLayout.SOUTH);
		}
		return packPanel;
	}
	private JPanel getMainPanel() {
		if (mainPanel == null) {
			mainPanel = new JPanel();
			mainPanel.setOpaque(false);
			mainPanel.setLayout(new GridLayout(0, 3, 0, 0));
			mainPanel.add(getAccPanel());
			mainPanel.add(getTicketsPanel());
			mainPanel.add(getPackPanel());
		}
		return mainPanel;
	}
	private JLabel getLblAccImg() {
		if (lblAccImg == null) {
			lblAccImg = new JLabel("");
			lblAccImg.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			lblAccImg.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/accImage.png")));
			lblAccImg.addMouseListener(accommodationsListener);
			lblAccImg.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblAccImg;
	}
	private JLabel getLblWelcome() {
		if (lblWelcome == null) {
			lblWelcome = new JLabel("");
			lblWelcome.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/welcome.png")));
			lblWelcome.setForeground(Color.decode("#0068AD"));
			lblWelcome.setFont(new Font("Helvetica Neue", Font.PLAIN, 89));
			lblWelcome.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblWelcome;
	}
	private JPanel getPnBtnAcc() {
		if (pnBtnAcc == null) {
			pnBtnAcc = new JPanel();
			pnBtnAcc.setOpaque(false);
			pnBtnAcc.add(getBtnNewButton());
			//pnBtnAcc.add(getBtnAcc());
		}
		return pnBtnAcc;
	}
	

	
//	private JLabel getBtnAcc() {
//		if (btnAcc == null) {
//			btnAcc = new JLabel("Accommodations");
//			btnAcc.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
//			btnAcc.addMouseListener(accommodationsListener);
//			btnAcc.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			btnAcc.setForeground(Color.WHITE);
//			btnAcc.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/buttonBackground.png")));
//			//lblNewLabel_2.setPreferredSize(new Dimension(100, 40));
//			btnAcc.setHorizontalTextPosition(JLabel.CENTER);
//		}
//		return btnAcc;
//	}
	
	private JLabel getLblPackImg() {
		if (lblPackImg == null) {
			lblPackImg = new JLabel("");
			lblPackImg.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					contenedor.showPanel("package");
				}
			});
			lblPackImg.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			lblPackImg.setHorizontalAlignment(SwingConstants.CENTER);
			lblPackImg.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/packImage.png")));
		}
		return lblPackImg;
	}
	
	private JPanel getPnBtnPack() {
		if (pnBtnPack == null) {
			pnBtnPack = new JPanel();
			pnBtnPack.setOpaque(false);
			pnBtnPack.add(getBtnNewButton_2());
			//pnBtnPack.add(getBtnPack());
		}
		return pnBtnPack;
	}
//	private JLabel getBtnPack() {
//		if (btnPack == null) {
//			btnPack = new JLabel("Packages");
//			btnPack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			btnPack.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/buttonBackground.png")));
//			btnPack.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					contenedor.showPanel("package");
//				}
//			});
//			btnPack.setHorizontalTextPosition(SwingConstants.CENTER);
//			btnPack.setForeground(Color.WHITE);
//		}
//		return btnPack;
//	}
	private JPanel getTicketsPanel() {
		if (ticketsPanel == null) {
			ticketsPanel = new JPanel();
			ticketsPanel.setOpaque(false);
			ticketsPanel.setLayout(new BorderLayout(0, 0));
			ticketsPanel.setBorder(new LineBorder(Color.decode("#FFF2DB"), 20));
			ticketsPanel.add(getLblTicketsImg(), BorderLayout.CENTER);
			ticketsPanel.add(getPanel(), BorderLayout.SOUTH);
		}
		return ticketsPanel;
	}
	private JLabel getLblTicketsImg() {
		if (lblTicketsImg == null) {
			lblTicketsImg = new JLabel("");
			lblTicketsImg.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			lblTicketsImg.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					contenedor.showPanel("ticket");
				}
			});
			lblTicketsImg.setHorizontalAlignment(SwingConstants.CENTER);
			lblTicketsImg.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/ticketsImg.png")));
		}
		return lblTicketsImg;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setOpaque(false);
			panel.add(getBtnNewButton_1());
			//panel.add(getLabel());
		}
		return panel;
	}
//	private JLabel getLabel() {
//		if (label == null) {
//			label = new JLabel("Packages");
//			label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//			label.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/buttonBackground.png")));
//			label.setHorizontalTextPosition(SwingConstants.CENTER);
//			label.addMouseListener(new MouseAdapter() {
//				@Override
//				public void mouseClicked(MouseEvent e) {
//					contenedor.showPanel("ticket");
//				}
//			});
//			label.setForeground(Color.WHITE);
//		}
//		return label;
//	}
	
	
	private class accListener extends MouseAdapter{
		@Override
		public void mouseClicked(MouseEvent e) {
			contenedor.showPanel("accommodation");
		}
	}
	

	
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("Accommodations");
			btnNewButton.setToolTipText("Shows the available accommodations.");
			btnNewButton.setMnemonic('c');
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("accommodation");
				}
			});
			btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnNewButton.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
			btnNewButton.setForeground(Color.WHITE);
			btnNewButton.setHorizontalTextPosition(SwingConstants.CENTER);
			btnNewButton.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/buttonBackground.png")));
			btnNewButton.setBorder(null);
		}
		return btnNewButton;
	}
	private JButton getBtnNewButton_1() {
		if (btnNewButton_1 == null) {
			btnNewButton_1 = new JButton("Tickets");
			btnNewButton_1.setToolTipText("Shows the available theme park tickets.");
			btnNewButton_1.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("ticket");
				}
			});
			btnNewButton_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnNewButton_1.setMnemonic('t');
			btnNewButton_1.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/buttonBackground.png")));
			btnNewButton_1.setHorizontalTextPosition(SwingConstants.CENTER);
			btnNewButton_1.setBorder(null);
			btnNewButton_1.setForeground(Color.WHITE);
		}
		return btnNewButton_1;
	}
	private JButton getBtnNewButton_2() {
		if (btnNewButton_2 == null) {
			btnNewButton_2 = new JButton("Packages");
			btnNewButton_2.setToolTipText("Shows the available travel packages.");
			btnNewButton_2.setMnemonic('p');
			btnNewButton_2.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
			btnNewButton_2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					contenedor.showPanel("package");
				}
			});
			btnNewButton_2.setHorizontalTextPosition(SwingConstants.CENTER);
			btnNewButton_2.setIcon(new ImageIcon(WelcomeScreen.class.getResource("/img/buttonBackground.png")));
			btnNewButton_2.setForeground(Color.WHITE);
			btnNewButton_2.setBorder(null);
		}
		return btnNewButton_2;
	}
	private JPanel getPnTitle() {
		if (pnTitle == null) {
			pnTitle = new JPanel();
			pnTitle.setBorder(new MatteBorder(10, 1, 1, 1, Color.decode("#FFF2DB")));
			pnTitle.setOpaque(false);
			pnTitle.add(getLblWelcome());
		}
		return pnTitle;
	}
}
