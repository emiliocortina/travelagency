package logic;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import javax.swing.JOptionPane;

import gui.BookingScreen;

public class Accommodation extends Product {

	public enum AccommodationType {
		AP, HO, AH
	}

	public AccommodationType type;
	private int category;
	private float price;
	private String name;
	private int capacity;
	private int nights;
	
	private boolean breakfast;
	private int people;

	private Date startDate;
	private Date endDate;
	
	

	public Accommodation(String code, AccommodationType type, int category, String name, ThemePark park, int capacity,
			float price) {
		super(code, park);
		this.name = name;
		this.type = type;
		this.category = category;
		this.capacity = capacity;
		if (park.isPromoted()) {
			this.price = (float) (0.8 * price);
		} else {
			this.price = price;
		}
	}
	
	public Accommodation(Accommodation acc) {
		super(acc.code, acc.park);
		this.name = acc.name;
		this.type = acc.type;
		this.category = acc.category;
		this.capacity = acc.capacity;
		this.price = acc.price;
		
		try {
			this.startDate=acc.startDate;
			this.endDate=acc.endDate;
			this.people=acc.people;
			this.breakfast=acc.breakfast;
			this.nights=acc.nights;
		}catch(Exception e) {
			
		}
		
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public float getPrice() {
		switch (type) {
		case AP:
			return price;
		case AH:
			return price;
		case HO:
			return price * people;
		default:
			return price;
		}
	}

	public void setPeople(int people) throws ZeroPeopleException, NoVacancyException {
		if (people <= 0) {
			throw new ZeroPeopleException();
		} else {
			if (people > capacity) {
				throw new NoVacancyException();
			} else {
				this.people = people;
			}
		}
	}

	public String getJpg() {
		return this.getCode() + ".jpg";
	}

	public static AccommodationType parseType(String typeToParse) {
		if (typeToParse.equals("AP")) {
			return AccommodationType.AP;
		}
		if (typeToParse.equals("AH")) {
			return AccommodationType.AH;
		}
		if (typeToParse.equals("HO")) {
			return AccommodationType.HO;
		}
		throw new RuntimeException("Accommodation type did not match any of the available!");
	}

	public String getType() {
		switch (type) {
		case AP:
			return "Apartment";
		case HO:
			return "Hotel";
		case AH:
			return "Aparthotel";
		default:
			return "Accommodation";
		}
	}

	public int getCategory() {
		return category;
	}

	public int getCapacity() {
		return capacity;
	}

	public float getDisplayedPrice() {
		return price;
	}

	public boolean isHotel() {
		return this.type.equals(AccommodationType.HO);
	}

	public String getDescription() {
		String s = "";
		s += "\nType: " + getType() + "\n\n" + "ThemePark: " + getPark().getName();
		if (!type.equals(AccommodationType.HO)) {
			s += "\n\nCapacity: " + getCapacity() + " people.";
			s += "\n\nPrice (per night): " + getPrice() + "�";
		} else {
			s += "\n\nPrice (per person and night): " + price + "�";
		}
		s += "\n\nPark Description: " + park.getDescription();
		return s;
	}

	@Override
	public String getClassification() {
		return "Accommodation";
	}

	public void setNights(int nights) throws ZeroNightsException {
		if (nights <= 0) {
			throw new ZeroNightsException();
		} else {
			this.nights = nights;
		}
	}

	@Override
	public boolean hasPeople() {
		if (type.equals(AccommodationType.HO)) {
			return people > 0;
		} else {
			return (people > 0 && people <= capacity);
		}
	}

	public void setDates(Date start, Date end) throws NullDateException {
		Date now = new Date();
		if (start != null && end != null) {
			if (end.compareTo(now) > 0) {
				long nights = BookingScreen.getDateDiff(start, end);
				if (nights > 0) {
					this.startDate = start;
					this.endDate = end;
					this.nights = (int) nights;
				}
			}
		} else {
			throw new NullDateException();
		}

	}

	public boolean canBeOrdered() {
		return nights > 0 && startDate != null && endDate != null && hasPeople();
	}

	public String toString() {
		String s = "";
		s += getName() + " - nights " + nights + " - people " + people + " - " + getFinalPrice();
		return s;
	}

	public float getFinalPrice() {
		float p = getPrice() * nights;
		if(isBreakfast()) {
			p=(float) (p*1.1);
		}
		return p;
	}

	@Override
	public ProductType getProductType() {
		return ProductType.ACC;
	}

	public int getPeople() {
		return people;
	}
	

	public String getStartingDate() {
		Date d = startDate;
		LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year  = localDate.getYear();
		int month = localDate.getMonthValue();
		int day   = localDate.getDayOfMonth();
		String s = day+"/"+month+"/"+year;
		return s;
	}
	
	public String getEndingDate() {
		Date d = endDate;
		LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year  = localDate.getYear();
		int month = localDate.getMonthValue();
		int day   = localDate.getDayOfMonth();
		String s = day+"/"+month+"/"+year;
		return s;
	}

	public boolean isBreakfast() {
		return breakfast;
	}

	public void setBreakfast(boolean breakfast) {
		this.breakfast = breakfast;
	}
	
	public String getBreakfast() {
		if(isBreakfast()) {
			return "yes";
		}
		return "no";
	}

	@Override
	public String getSummary() {
		String s = "";
		s+="Accommodation: "+getCode()+ " / "+ getType() + " / "+ getCategory() +" / "+ getName() +" / "+ getPark().getName() +" / Breakfast ";
		if(breakfast) {
			s+="Y";
		}else {
			s+="N";
		}
		s+="\nInitial date: " + getStartingDate() + " / Nights: "+nights;
		s+="N. People: "+people;
		return s;
	}
}
