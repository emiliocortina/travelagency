package logic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;

public class Agency {

	private ArrayList<Accommodation> accommodations;
	private ArrayList<Package> packages;
	private ArrayList<Ticket> tickets;

	private ArrayList<ThemePark> parks;

	private ArrayList<Product> order;
	
	private ThemePark promotion;

	public Agency() {
		parks = new ArrayList<ThemePark>();
		accommodations = new ArrayList<Accommodation>();
		packages = new ArrayList<Package>();
		tickets = new ArrayList<Ticket>();
		order = new ArrayList<Product>();
		
		loadFiles();
		
		
		//Testing
//		System.out.println("Parks: "+parks.size());
//		System.out.println("Accommodations: "+accommodations.size());
//		System.out.println("Packages: "+packages.size());
//		System.out.println("Tickets: "+tickets.size());
//		System.out.println("Order: "+order.size());
		
	}

	public void loadFiles() {
		//Parks must be the first thing loaded up because every product needs a park associated with.
		loadParks();
		
		//Accommodations must be loaded first than packages or exceptions will be thrown.
		loadAccommodations();
		loadTickets();
		loadPackages();
	}
	
	public void loadParks() {
		String linea = "";
		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/tematicos.dat"));
			while (fichero.ready()) {
				linea = fichero.readLine();
				String[] trozos = linea.split("@");
				parks.add(new ThemePark(trozos[0], trozos[1], trozos[2], trozos[3], trozos[4]));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			JOptionPane.showMessageDialog(null, "El archivo no se ha encontrado");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
		
		promotion = parks.get((int) (Math.random()*parks.size()));
		promotion.setPromoted(true);
		System.out.println(promotion.getName());
	}
	
	public void loadAccommodations() {
		String linea = "";
		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/alojamientos.dat"));
			while (fichero.ready()) {
				linea = fichero.readLine();
				String[] trozos = linea.split("@");
				accommodations.add(new Accommodation(trozos[0], Accommodation.parseType(trozos[1]), Integer.parseInt(trozos[2]), trozos[3], getPark(trozos[4]), Integer.parseInt(trozos[5]), Float.parseFloat(trozos[6])));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			JOptionPane.showMessageDialog(null, "El archivo no se ha encontrado");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}
	
	public void loadTickets() {
		String linea = "";
		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/entradas.dat"));
			while (fichero.ready()) {
				linea = fichero.readLine();
				String[] trozos = linea.split("@");
				tickets.add(new Ticket(trozos[0], getPark(trozos[1]), Float.parseFloat(trozos[2]), Float.parseFloat(trozos[3])));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			JOptionPane.showMessageDialog(null, "El archivo no se ha encontrado");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}
	
	public void loadPackages() {
		String linea = "";
		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/paquetes.dat"));
			while (fichero.ready()) {
				linea = fichero.readLine();
				String[] trozos = linea.split("@");
				packages.add(new Package(trozos[0], trozos[1], getPark(trozos[2]), getAccommodation(trozos[3]), Integer.parseInt(trozos[4]), Float.parseFloat(trozos[5]), Float.parseFloat(trozos[6]) ));
			}
			fichero.close();
		} catch (FileNotFoundException fnfe) {
			JOptionPane.showMessageDialog(null, "El archivo no se ha encontrado");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
	}
	
	public Accommodation getAccommodation(String code) {
		for(Accommodation acc : accommodations) {
			if(acc.getCode().equals(code)) {
				return acc;
			}
		}
		throw new RuntimeException("Tried to get the code of a non-existing accommodation!");
	}
	
	public ThemePark getPark(String code) {
		for(ThemePark park : parks) {
			if(park.getCode().equals(code)) {
				return park;
			}
		}
		throw new RuntimeException("Tried to get the code of a non-existing park!");
	}

	
	public ArrayList<Accommodation> getAccommodations() {
		return accommodations;
	}
	

	public ArrayList<Package> getPackages() {
		return packages;
	}
	

	public ArrayList<Ticket> getTickets() {
		return tickets;
	}
	

	public ArrayList<ThemePark> getParks() {
		return parks;
	}
	

	public ArrayList<Product> getOrder() {
		return order;
	}

	public ArrayList<Accommodation> getPromotedAcc(){
		ArrayList<Accommodation> accs = new ArrayList<Accommodation>();
		for(Accommodation a : accommodations) {
			if(a.getPark().isPromoted()) {
				accs.add(a);
			}
		}
		return accs;
	}
	
	public ArrayList<Package> getPromotedPacks(){
		ArrayList<Package> accs = new ArrayList<Package>();
		for(Package a : packages) {
			if(a.getPark().isPromoted()) {
				accs.add(a);
			}
		}
		return accs;
	}
	
	public ArrayList<Ticket> getPromotedTicket(){
		ArrayList<Ticket> accs = new ArrayList<Ticket>();
		for(Ticket a : tickets) {
			if(a.getPark().isPromoted()) {
				accs.add(a);
			}
		}
		return accs;
	}
	
	
	public void addToOrder(Product product) {
		for(Product p : order) {
			if(p.equals(product)) {
				break;
			}
		}
		order.add(product);
	}
	
	public float getTotalPrice() {
		float price = 0;
		for(Product p : order) {
			price+=p.getFinalPrice();
		}
		return price;
	}
	
	public void removeFromOrder(Product p) {
		order.remove(p);
	}
	
	public void resetOrder() {
		order.removeAll(order);
	}
	
	public ArrayList<Accommodation> getOrderedAcc(){
		ArrayList<Accommodation> accs = new ArrayList<Accommodation>();
		for(Product a : order) {
			if(a instanceof Accommodation) {
				accs.add((Accommodation) a);
			}
		}
		return accs;
	}
	
	public float getAccsPrice(){
		float p=0;
		for(Product a : order) {
			if(a instanceof Accommodation) {
				p+=a.getFinalPrice();
			}
		}
		return p;
	}

	
	public ArrayList<Package> getOrderedPack(){
		ArrayList<Package> accs = new ArrayList<Package>();
		for(Product a : order) {
			if(a instanceof Package) {
				accs.add((Package) a);
			}
		}
		return accs;
	}
	
	public float getPacksPrice(){
		float p=0;
		for(Product a : order) {
			if(a instanceof Package) {
				p+=a.getFinalPrice();
			}
		}
		return p;
	}
	
	public ArrayList<Ticket> getOrderedTicket(){
		ArrayList<Ticket> accs = new ArrayList<Ticket>();
		for(Product a : order) {
			if(a instanceof Ticket) {
				accs.add((Ticket) a);
			}
		}
		return accs;
	}
	
	public float getTicketsPrice(){
		float p=0;
		for(Product a : order) {
			if(a instanceof Ticket) {
				p+=a.getFinalPrice();
			}
		}
		return p;
	}
	
	
	public String generateReceipt(String customerName, String customerSurname, String customerID) {
		String s = "";
		s+="TRAVEL AGENCY PETER PARKER";
		Date now = new Date();
		s+="\nBOOKING CONFIRMATION - " + now.toString();
		s+="\n-------------------------------------";
		s+="\n" + customerID + " - "+ customerName+" "+customerSurname;
		s+="\n**** BOOKING/S DATA ****";
		s+="\n\n** THEME PARKS **";
		for(Package pack : getOrderedPack()) {
			s+=pack.getSummary()+"\n";
		}
		s+="\n\n** ACCOMMODATIONS **";
		for(Accommodation acc : getOrderedAcc()) {
			s+=acc.getSummary()+"\n";
		}
		s+="\n\n** TICKETS **";
		for(Ticket t : getOrderedTicket()) {
			s+=t.getSummary()+"\n";
		}
		s+="\n**** PAYMENT ****";
		s+="\nTheme parks:          "+getPacksPrice()+"�";
		s+="\nAccommodations:       "+getAccsPrice()+"�";
		s+="\nTickets:              "+getTicketsPrice()+"�";
		s+="\nFinal price:          "+(getTicketsPrice()+getPacksPrice()+ getAccsPrice() )+"�" ;
		return s;
	}
	
	  public int saveFile(String line, String name) {
		    String fileName = "files/"+name+".dat";
		    try {
		         BufferedWriter fichero = new BufferedWriter(new FileWriter(fileName));
		         fichero.write(line);
		         fichero.close();
		         return(0);
		     }
		    catch (FileNotFoundException fnfe) {
		    	System.out.println("File could not be savd");
		    	return(-1);
		    }
		    catch (IOException ioe) {
		    	new RuntimeException("Input/output error.");
		    	return(-2);
		    }
		  }
	
}
