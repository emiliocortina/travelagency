package logic;

public class NoVacancyException extends Exception {

}
