package logic;

public class NullDateException extends Exception {

}
