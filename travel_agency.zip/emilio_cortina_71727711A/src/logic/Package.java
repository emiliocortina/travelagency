package logic;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class Package extends Product {

	private String name;
	private Accommodation accommodation;
	private int days;
	private float adultPrice;
	private float childrenPrice;

	private int adults = 0;
	private int children = 0;
	private Date startDate;

	public Package(String code, String name, ThemePark park, Accommodation accommodation, int days, float adultPrice,
			float childrenPrice) {
		super(code, park);
		this.name = name;
		this.accommodation = accommodation;
		this.days = days;
		
		if (park.isPromoted()) {
			this.adultPrice = (float) (0.8 * adultPrice);
			this.childrenPrice = (float) (0.8 * childrenPrice);
		} else {
			this.adultPrice = adultPrice;
			this.childrenPrice = childrenPrice;
		}

	}

	public Package(Package pack) {
		super(pack.code, pack.park);
		this.name = pack.name;
		this.accommodation = pack.accommodation;
		this.days = pack.days;
		this.adultPrice = pack.adultPrice;
		this.childrenPrice = pack.childrenPrice;
		
		try {
			this.startDate=pack.startDate;
			this.adults=pack.adults;
			this.children=pack.children;
			
		}catch(Exception e) {
			
		}
	}
	
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public float getPrice() {
		return ((children * childrenPrice) + (adults * adultPrice));
	}

	public void setChildren(int children) {
		this.children = children;
	}

	public void setAdults(int adults) throws ZeroPeopleException {
		if(adults<=0) {
			throw new ZeroPeopleException();
		}
		this.adults = adults;
	}

	@Override
	public String getJpg() {
		return this.getCode() + ".jpg";
	}

	@Override
	public String getDescription() {
		String s = "";
		s += "\nAccommodation: " + accommodation.getName() + "\nTheme Park: " + getPark().getName() + "\nLength: "
				+ days + " days." + "\nAdult price: " + adultPrice + "�\nChildren price: " + childrenPrice
				+ "�\n\nDescription: " + park.getDescription() + ".";
		return s;
	}

	@Override
	public String getClassification() {
		return "Package";
	}

	public Accommodation getAccommodation() {
		return accommodation;
	}

	public float getDisplayedPrice() {
		return adultPrice;
	}

	@Override
	public boolean hasPeople() {
		return adults > 0;
	}

	public void setDate(Date start) throws NullDateException {
		if(start==null) {
			throw new NullDateException();
		}
		Date now = new Date();
		if (start.compareTo(now) > 0) {
			startDate = start;
		}
	}

	public int getLength() {
		return days;
	}

	@Override
	public boolean canBeOrdered() {
		return hasPeople() && startDate != null;
	}

	public float getFinalPrice() {
		return getPrice();
	}

	public String toString() {
		String s = "";
		s += getName() + " - days " + days + " - adults " + adults + " - children " + children + " - " + getPrice()
				+ " �";
		return s;
	}

	@Override
	public ProductType getProductType() {
		return ProductType.PACK;
	}

	public int getDays() {
		return days;
	}

	public int getAdults() {
		return adults;
	}

	public int getChildren() {
		return children;
	}
	
	public String getStartingDate() {
		Date d = startDate;
		LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year  = localDate.getYear();
		int month = localDate.getMonthValue();
		int day   = localDate.getDayOfMonth();
		String s = day+"/"+month+"/"+year;
		return s;
	}
	
	public String getEndingDate() {
		Date d = startDate;
		LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		localDate = localDate.plusDays(days);
		int year  = localDate.getYear();
		int month = localDate.getMonthValue();
		int day   = localDate.getDayOfMonth();
		String s = day+"/"+month+"/"+year;
		return s;
	}

	@Override
	public String getSummary() {
		String s = "";
		s+="Package: "+getCode()+ " / "+ getName() +" / "+ getPark().getName() +" / "+days+" DAYS";
		s+="\nInitial date: " + getStartingDate();
		s+="\nN. Adults: "+adults+" / "+"N. Children: "+children;
		return s;
	}

}
