package logic;

import java.util.Date;


public abstract class Product {

	protected String code;
	protected ThemePark park;
	private Date startDate;
	private Date endDate;
	
	public Product(String code, ThemePark park) {
		this.code=code;
		this.park=park;
		
	}
	
	
	public abstract String getName();
	public abstract float getPrice();
	public abstract String getJpg();
	public abstract String getDescription();
	public abstract String getClassification();
	public abstract float getDisplayedPrice();
	public abstract boolean hasPeople();
	public abstract boolean canBeOrdered();
	public abstract float getFinalPrice();
	public abstract ProductType getProductType();
	public abstract String getSummary();
	
	public String getCode() {
		return code;
	}
	
	public ThemePark getPark() {
		return park;
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCountry() {
		return park.getCountry();
	}
	
	public String getCity() {
		return park.getCity();
	}



	
	

	
}
