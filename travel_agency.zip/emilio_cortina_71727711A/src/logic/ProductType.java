package logic;

public enum ProductType {
	PACK, ACC, TICKET
}
