package logic;

public class ThemePark {
	
	private String code;
	private String name;
	private String country;
	private String city;
	private String description;
	private boolean promoted;
	
	public ThemePark(String code, String name, String country, String city, String description) {
		this.code=code;
		this.name=name;
		this.country=country;
		this.city=city;
		this.description=description;
		
	}

	public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public String getCity() {
		return city;
	}

	public boolean isPromoted() {
		return promoted;
	}

	public void setPromoted(boolean promoted) {
		this.promoted = promoted;
	}
	
	
}
