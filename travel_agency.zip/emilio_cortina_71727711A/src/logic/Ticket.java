package logic;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import gui.BookingScreen;

public class Ticket extends Product {

	public int getAdults() {
		return adults;
	}

	public int getChildren() {
		return children;
	}

	public int getDays() {
		return days;
	}

	private float adultPrice;
	private float childrenPrice;
	private int adults;
	private int children;
	private Date startDate;
	private Date endDate;
	private int days;

	public Ticket(String code, ThemePark park, float adultPrice, float childrenPrice) {
		super(code, park);
		if (park.isPromoted()) {
			this.adultPrice = (float) (0.8 * adultPrice);
			this.childrenPrice = (float) (0.8 * childrenPrice);
		} else {
			this.adultPrice = adultPrice;
			this.childrenPrice = childrenPrice;
		}
	}

	public Ticket(Ticket t) {
		super(t.code, t.park);
		this.adultPrice = t.adultPrice;
		this.childrenPrice = t.childrenPrice;

		try {
			this.startDate = t.startDate;
			this.endDate = t.endDate;
			this.adults = t.adults;
			this.children = t.children;
			this.days = t.days;

		} catch (Exception e) {

		}
	}

	@Override
	public String getName() {
		return park.getName();
	}

	@Override
	public float getPrice() {
		return ((children * childrenPrice) + (adults * adultPrice));
	}

	public void setAdults(int adults) throws ZeroPeopleException {
		if (adults <= 0) {
			throw new ZeroPeopleException();
		} else {
			this.adults = adults;
		}
	}

	public void setChildren(int children) {
		this.children = children;
	}

	@Override
	public String getJpg() {
		return this.park.getCode() + ".jpg";
	}

	@Override
	public String getDescription() {
		String s = "";
		s += "\nTheme Park: " + getPark().getName();
		s += "\nLocation: " + getCity() + ", " + getCountry() + ".";
		s += "\n\nAdult price: " + getAdultPrice() + "�";
		s += "\nChild price: " + getChildrenPrice() + "�";
		s += "\n\nDescription: " + park.getDescription() + ".";
		s += "\n\n\n*If you want a ticket for just one day select the same start and end date.";
		return s;
	}

	@Override
	public String getClassification() {
		return "Theme Park Ticket";
	}

	public float getAdultPrice() {
		return adultPrice;
	}

	public float getChildrenPrice() {
		return childrenPrice;
	}

	@Override
	public float getDisplayedPrice() {
		return adultPrice;
	}

	@Override
	public boolean hasPeople() {
		return adults > 0;
	}

	public void setDates(Date start, Date end) throws NullDateException {
		if (start == null || end == null) {
			throw new NullDateException();
		}
		Date now = new Date();
		if (start.compareTo(now) > 0 && end.compareTo(now) > 0) {
			long days = 1 + BookingScreen.getDateDiff(start, end);
			if (days > 0) {
				this.days = (int) days;
				this.startDate = start;
				this.endDate = end;
			}
		}
	}

	@Override
	public boolean canBeOrdered() {
		return hasPeople() && startDate != null && endDate != null;
	}

	public float getFinalPrice() {
		return getPrice() * days;
	}

	public String toString() {
		String s = "";
		s += getName() + " - days " + days + " - adults " + adults + " - children " + children + " - " + getFinalPrice()
				+ " �";
		return s;
	}

	@Override
	public ProductType getProductType() {
		// TODO Auto-generated method stub
		return ProductType.TICKET;
	}

	public String getStartingDate() {
		Date d = startDate;
		LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year = localDate.getYear();
		int month = localDate.getMonthValue();
		int day = localDate.getDayOfMonth();
		String s = day + "/" + month + "/" + year;
		return s;
	}

	public String getEndingDate() {
		Date d = endDate;
		LocalDate localDate = d.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		int year = localDate.getYear();
		int month = localDate.getMonthValue();
		int day = localDate.getDayOfMonth();
		String s = day + "/" + month + "/" + year;
		return s;
	}

	@Override
	public String getSummary() {
		String s = "";
		s += "Ticket: " + getCode() + " / " + getName() + " / " + getPark().getName();
		s += "\nInitial date: " + getStartingDate() + " / Days: " + days;
		s += "\nN. Adults: " + adults + " / " + "N. Children: " + children;
		return s;
	}

}
