package logic;

public class ZeroNightsException extends Exception {

}
