package logic;

public class ZeroPeopleException extends Exception {

}
